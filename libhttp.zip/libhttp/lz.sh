make clean

make	
gcc -c main.c
gcc -static main.o libhttp.a
clear
./a.out http://www.tbyh.cn/min.php
