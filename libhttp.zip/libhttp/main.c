


#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>

#include "http.h"

int post(int sd, struct http_url *url) {
	char buf[1024];
	char buf_1[1024];

	snprintf(
		buf,
		sizeof(buf),
		"\
POST /%s HTTP/1.1\r\n\
User-Agent: Mozilla/4.0 (Linux)\r\n\
Host: %s\r\n\
Accept: */*\r\n\
Content-Length: 13\r\n\
Connection: close\r\n\
\r\n\
username=hjm12345&password=kkk12345&button2=登录\r\n\
\r\n",
		url->query,
		url->host);
		
	snprintf(
		buf_1,
		sizeof(buf_1),
		"\
GET /%s HTTP/1.1\r\n\
User-Agent: Mozilla/4.0 (Linux)\r\n\
Host: %s\r\n\
Accept: */*\r\n\
Connection: close\r\n\
\r\n",
		url->query,
		url->host);
//printf("%s\n",buf_1);
	if (http_send(sd, buf_1)) {
		perror("http_send");
		return -1;
	}

	return 0;
}

int post_1(int sd, struct http_url *url) {
	char buf[1024];
	char buf_1[1024];

	snprintf(
		buf,
		sizeof(buf),
		"\
POST /a.php HTTP/1.1\r\n\
User-Agent: Mozilla/4.0 (Linux)\r\n\
Host: %s\r\n\
Accept: */*\r\n\
Content-Length: 13\r\n\
Connection: close\r\n\
\r\n\
username=hjm12345&password=kkk12345&button2=登录\r\n\
\r\n",
		url->host);
		
	snprintf(
		buf_1,
		sizeof(buf_1),
		"\
GET /%s HTTP/1.1\r\n\
User-Agent: Mozilla/4.0 (Linux)\r\n\
Host: %s\r\n\
Accept: */*\r\n\
Connection: close\r\n\
\r\n",
		url->query,
		url->host);
//printf("%s\n",buf_1);
	if (http_send(sd, buf_1)) {
		perror("http_send");
		return -1;
	}

	return 0;
}

int main(int argc, char **argv) {
	struct http_url *url;
	struct http_message msg;
	int sd;

	if (!(url = http_parse_url(*++argv)) ||
			!(sd = http_connect(url))) {
		free(url);
		perror("http_connect");
		return -1;
	}

	memset(&msg, 0, sizeof(msg));
  
  
	if (!post_1(sd, url)) {
		while (http_response(sd, &msg) > 0) {
			if (msg.content) {
			 // printf("end\n");
				write(1, msg.content, msg.length);
			//	printf("*********************************************\n");
			//	printf("%s\n",msg.content);
       // printf("*********************************************\n");
			}
		}
		//printf("%s\n",msg.headers);
	}
	/*
	if (!post_1(sd, url)) {
		while (http_response(sd, &msg) > 0) {
			if (msg.content) {
			 // printf("end\n");
		
	  	write(1, msg.content, msg.length);
			//	printf("*********************************************\n");
			//	printf("%s\n",msg.content);
       // printf("*********************************************\n");
			}
		}
		//printf("%s\n",msg.headers);
	}
	*/
	

	free(url);
	close(sd);
	
	
/*
	if (msg.header.code != 200) {
		fprintf(
			stderr,
			"error: returned HTTP code %d\n",
			msg.header.code);
	}
*/
	return 0;
}

