import tag from 'html-tag-js';
import mustache from 'mustache';
import Page from '../components/page';
import contextMenu from '../components/contextMenu';
import _template from './fileBrowser.hbs';
import _list from './list.hbs';
import './fileBrowser.scss';
import util from './util';
import helpers from '../src/utils/helpers';
import fsOperation from '../src/fileSystem/fsOperation';



function FileBrowserInclude(type, option) {
  
  return new Promise((_resolve, reject) => {
//alert(type);
   editorManager.sidebar.hide();
    const $page = Page('File Browser');
    const $content = tag.parse(mustache.render(_template, {
      type
    }));
    const $navigation = $content.querySelector('.navigation');
    const actionsToDispose = [];

    const root = 'file:///storage/';
    let cachedDir = {};
    let currentDir = {
      url: "/",
      name: 'File browser'
    };
    let folderOption;
   // alert(JSON.stringify($content))
    $content.addEventListener('click', handleClick);
    $content.addEventListener('contextmenu', handleContextMenu);
    
    $page.append($content);
    document.body.append($page);
    
    side_push({
      id: 'filebrowser',
      action: function () {
        reject({
          error: 'user canceled',
          code: 0
        });
        $page.hide();
      }
    });
    $page.onhide = function () {
      let id = '';
      while ((id = actionsToDispose.pop())) {
        side_remove(id);
      }
      side_remove('filebrowser');
      $content.removeEventListener('click', handleClick);
      $content.removeEventListener('contextmenu', handleContextMenu);
    };
    
    
    if (type === 'folder') {
      const openFolder = tag('button', {
        textContent: option || 'select folder'
      });
      folderOption = tag('footer', {
        className: 'button-container',
        child: openFolder
      });

      $page.setAttribute('footer-height', 1);
      $page.append(folderOption);

      openFolder.onclick = () => {
       // alert("openFolder")
        $page.hide();
       // alert(JSON.stringify(currentDir))
        resolve(currentDir);
      };
    }
    
    renderStorages();

    function renderStorages() {
      renderList(getStorageList());
    }
    
    function getStorageList() {
      const list = [];

      const path = cordova.file.externalRootDirectory;
      util.pushFolder(list, 'Internal storage', path);
    //  alert(list.name)
      /*
      customUuid.map(storage => {
        util.pushFolder(list, storage.name, storage.uri, {
          uuid: storage.uuid,
          storageType: "SD"
        });
      });
      */
      //  const _ftpaccounts = decryptAccounts(ftpaccounts);
      /*
      _ftpaccounts.map(account => {

        const {
          mode,
          security,
          name
        } = account;

        let url = Url.formate({
          protocol: "ftp:",
          ...account,
          query: {
            mode,
            security
          }
        });
        util.pushFolder(list, name, url, {
          uuid: account.id,
          "ftp-account": true,
          storageType: "FTP"
        });

      });
     */
     /*
      if (type === "file") {
        util.pushFolder(list, "Select document", null, {
          "open-doc": true
        });
      }
     */
      cachedDir["/"] = {
        name:"name",
        list
      };

      return list;
    }

    function renderList(list) {
    //  delete localStorage.lastDir;
      if (type === 'folder')
        folderOption.classList.add('disabled');

      navigate("/", "/");
      
      currentDir.url = "/";
      currentDir.name = "File Browser";
      $page.settitle('File Browsers');
      
      
      render(
       helpers.sortDir(list,{showHiddenFiles: false,sortByName: true})
        );
      
    }

    function render(list) {
      
      const $list = tag.parse(mustache.render(_list, {
        msg: 'empty folder message',
        list
      }));
//    alert(mustache.render(_list, {msg: 'empty folder message',list}))
    //
   //   alert(JSON.stringify(list));
      const $oldList = $content.querySelector('#list');
      if ($oldList) $oldList.remove();
      $content.append($list);
      $list.focus();
    }
    
    function loadDir(path = "/", name = 'File Browser') {

      let url = path;

      if (typeof path === 'object') {
        url = path.url;
        name = path.name;
      }
     // alert(url+","+name);
      if (url === "/"){
        
        return renderStorages();
      } 

      if (url in cachedDir) {
      //  alert(url+","+name);
        
        update();
        const item = cachedDir[url];
        render(item.list);
        const $list = tag.get('#list');
        $list.scrollTop = item.scroll;
        name = item.name;
        
      } else {
      //  alert(url+","+name);
        
        const timeout = setTimeout(() => {
          //dialogs.loader.create('', strings.loading + '...');
        }, 100);
        fsOperation(url)
          .then(fs => {
            return fs.lsDir();
          }).then(list => {
            update();
            list = helpers.sortDir(list,
              {
                showHiddenFiles: false,
                sortByName: true
            }
            );
            cachedDir[url] = {
              name,
              list
            };
            render(list);
          })/*
          .catch(err => {
            actionStack.remove(currentDir.url);
            helpers.error(err, url);
            console.error(err);
          })
          .finally(() => {
            clearTimeout(timeout);
            dialogs.loader.destroy();
          });
      }*/
      
      
      
      
    }
    function update() {
        if (url === root) {
        //  $addMenuToggler.classList.add('disabled');
          if (type === 'folder') folderOption.classList.add('disabled');
        } else {
         // $addMenuToggler.classList.remove('disabled');
          if (type === 'folder') folderOption.classList.remove('disabled');
        }

        localStorage.lastDir = url;
        currentDir.url = url;
        currentDir.name = name;
        const $list = tag.get('#list');
        if ($list) $list.scrollTop = 0;
        navigate(name, url);
        $page.settitle(name);
      }
}
  
    function resolve(data) {
      localStorage.setItem("lastDir", currentDir.url);
      _resolve(data);
    }
    
    function handleClick(e, contextMenu) {
      /**
       * @type {HTMLElement}
       */
      const $el = e.target;
      let action = $el.getAttribute('action');
      if (!action) return;

      const url = $el.getAttribute('url');
      const name = $el.getAttribute('name');
      const opendoc = $el.getAttribute('open-doc');
      const uuid = $el.getAttribute('uuid');
      const isFTP = $el.hasAttribute('ftp-account');
      
      if (opendoc) action = "open-doc";
     // alert("opendoc:"+opendoc)
    //  alert("action:"+action)
      switch (action) {
        case 'navigation':
        case 'folder':
          folder();
          break;
        case 'file':
        //  file();
          break;
        case "open-doc":
         // openDoc();
          break;
      }
      

      function folder() {
        if (contextMenu !== 'contextmenu') {
          const currentUrl = currentDir.url;
          cachedDir[currentUrl].scroll = tag.get('#list').scrollTop;
          actionsToDispose.push(currentUrl);
          side_push({
            id: currentUrl,
            action: function () {
              navigate.pop();
            }
          });
         // alert("url:"+url)
          loadDir(url, name);
        //alert("here")
          
        } else {
         // cmhandle();
        }
        
      }
/*
      function file() {
        if (contextMenu !== "contextmenu") {
          if (typeof option === 'function' && option(name)) {
            $page.hide();
            resolve({
              url
            });
          }
        } else {
          cmhandle();
        }
      }

      function cmhandle() {
        const enabled = (currentDir.url === "/" && !!uuid) || currentDir.url !== "/";
        if (appSettings.value.vibrateOnTap) navigator.vibrate(constants.VIBRATION_TIME);
        dialogs.select('', [
            ['delete', strings.delete, 'delete', enabled],
            ['rename', strings.rename, 'edit', enabled]
          ])
          .then(res => {

            switch (res) {
              case 'delete':
                dialogs.confirm(strings.warning.toUpperCase(), strings["delete {name}"].replace('{name}', name))
                  .then(remove);
                break;
              case 'rename':
                dialogs.prompt(strings.rename, name, "text", {
                  match: constants.FILE_NAME_REGEX
                }).then(newname => {
                  rename(newname);
                });
                break;
            }

          });
      }

      function rename(newname) {
        if (uuid) {
          renameStorage(newname);
        } else {
          renameFile(newname);
        }
      }

      function remove() {
        if (uuid) {
          removeStorage();
        } else {
          removeFile();
        }
      }

      function renameFile(newname) {
        fsOperation(url)
          .then(fs => {
            return fs.renameTo(newname);
          })
          .then(newUrl => {
            openFolder.updateItem(url, newUrl, newname);
            window.plugins.toast.showShortBottom(strings.success);
            delete cachedDir[currentDir.url];
            loadDir(currentDir);
          })
          .catch(err => {
            helpers.error(err);
            console.error(err);
          });
      }

      function removeFile() {
        fsOperation(url)
          .then(fs => {
            if (action === "file") return fs.deleteFile();
            if (action === "folder") return fs.deleteDir();
          })
          .then(() => {
            openFolder.removeItem(url);
            window.plugins.toast.showShortBottom(strings.success);
            delete cachedDir[currentDir.url];
            loadDir(currentDir);
          })
          .catch(err => {
            console.error(err);
            helpers.error(err);
          });
      }

      function removeStorage() {
        if (isFTP) {
          ftpaccounts = ftpaccounts.filter(account => account.id !== uuid);
          localStorage.ftpaccounts = JSON.stringify(ftpaccounts);
        } else {
          customUuid = customUuid.filter(storage => storage.uuid !== uuid);
          localStorage.customUuid = JSON.stringify(customUuid);
        }

        navigate.pop();
        renderStorages();
      }

      function renameStorage(newname) {
        if (isFTP) {
          ftpaccounts = ftpaccounts.map(account => {
            if (account.id === uuid) account.name = newname;
            return account;
          });
          localStorage.ftpaccounts = JSON.stringify(ftpaccounts);
        } else {
          customUuid = customUuid.map(storage => {
            if (storage.uuid === uuid) storage.name = newname;
            return storage;
          });
          localStorage.customUuid = JSON.stringify(customUuid);
        }

        navigate.pop();
        renderStorages();
      }

      function openDoc() {
        sdcard.openDocumentFile(res => {
          res.url = res.uri;
          resolve(res);
          $page.hide();

        }, err => {
          helpers.error(err);
          console.error(err);
        });
      }
    */
      
      
    }

    function handleContextMenu(e) {
      handleClick(e, 'contextmenu');
    }

    function navigate(name, url) {
      let $nav = $navigation.querySelector(`[url="${url}"]`);
      const $old = $navigation.querySelector('.active');
      if ($old) $old.classList.remove('active');

      //If navigate to previous directories, clear the rest navigation
      if ($nav) {
        let $topNav;
        while (($topNav = $navigation.lastChild) !== $nav) {
          const url = $topNav.getAttribute('url');
          side_remove(url);
          actionsToDispose.pop();
          $topNav.remove();
        }

        side_remove(url);
        actionsToDispose.pop();
        return $nav.classList.add('active');
      }


      $nav = tag('span', {
        className: 'nav active',
        attr: {
          action: 'navigation',
          
          text: name
          
        },
        tabIndex: -1
      });

      $navigation.append($nav);
      $navigation.scrollLeft = $navigation.scrollWidth;
    }

    navigate.pop = function () {
      const $nav = $navigation.lastChild.previousElementSibling;
      if ($nav) {
        const url = $nav.getAttribute('url');
        navigate(undefined, url);
        loadDir(url);
      }
    };

    
});
  
}


const stack = [];
 function side_push(fun) {
      stack.push(fun);
  }

    

function side_remove(id) {
    for (let i = 0; i < stack.length; ++i) {
        let action = stack[i];
        if (action.id === id) {
            stack.splice(i, 1);
            return true;
        }
    }

    return false;
}

export default FileBrowserInclude;
