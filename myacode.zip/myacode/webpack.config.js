const path = require('path');
const MiniCssExtractPlugin = require("mini-css-extract-plugin");


module.exports = {
  entry: './src/index.js',
  output: {
    path: path.resolve(__dirname, "www/js/build/"),

    filename: "[name].build.js"
  },
   module: {

    rules: [
      {
        test: /\.hbs$/,
        use: ['raw-loader']
      },
     {
        test: /\.js$/,
        use: {
          loader: "babel-loader",
          options: {
            presets: ["@babel/preset-env"]
          }
        }
      },
       {

        test: /\.(sa|sc|c)ss$/,

        use: [{
            loader: MiniCssExtractPlugin.loader,
            options: {
              publicPath: "../../"

            }
          },
          "css-loader?url=false",
          "postcss-loader",
          "sass-loader"
        ]
      }
      ]
      
    },
       resolve: {
      fallback: {
        path: require.resolve('path-browserify'),
        crypto: false,
      },
      modules: ["node_modules", "src"],
    }, 
      plugins: [

    new MiniCssExtractPlugin({

      filename: "../../css/build/[name].css",
      // chunkFilename: "../css/[id].css"
    }),
    // new BundleAnalyzerPlugin()
  ],
    
  mode:  "development"
};
