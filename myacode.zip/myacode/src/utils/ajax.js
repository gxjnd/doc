import ajax from '@deadlyjack/ajax';

export default ajax;