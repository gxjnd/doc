//com.yc.eff


import tag from 'html-tag-js';
import "html-tag-js/polyfill";
export let scrollAnimationFrame; // scroll animation frame id

export default  function addTouchListeners(editor,minimal){
  
  const SCROLL_CAPTURE_TIME = 30; // timeToSelectText
  const { renderer, container: $el } = editor;
  const { scroller, $gutter } = renderer;

  let reverseScrolling = false;
  const $start = tag('span', {
    className: 'cursor start',
    dataset: {
      size: 30,
    },
    size: 30,
  });


  const $end = tag('span', {
    className: 'cursor end',
    dataset: {
      size: 30,
    },
    size: 30,
  });
  
  const $plugincursor= tag('div', {
    className: 'plugincursor',
    innerHTML:'+'
  });
  const $wrapcursor= tag('div', {
    className: 'wrapcursor',
    innerHTML:'\\'
  });
  
  const $cursor = tag('span', {
    className: 'cursor single',
    dataset: {
      size: 30,
    },
    get size() {
      const widthSq = 30 * 30 * 2;
      const actualWidth = Math.sqrt(widthSq);
      delete this.size;
      this.size = actualWidth;
      return actualWidth;
    },
    startHide() {
      clearTimeout($cursor.dataset.timeout);
      $cursor.dataset.timeout = setTimeout(() => {
        $cursor.remove();
        hideMenu();
      }, 3000);
    },
  });
  

  const $menu = tag('div', {
        className: 'cursor-menu'
    });

  const timeToSelectText = 500; // ms
  const config = { passive: false }; 
  const ACE_NO_CURSOR = '.ace_gutter,.ace_gutter *,.ace_fold,.ace_inline_button';
  const Plugin_icno = '.plugincursor,.wrapcursor';

  
  let scrollTimeout; // timeout to check if scrolling is finished
  let menuActive; // true if menu is active
  let mode; // cursor, selection or scroll
  let moveY; // touch difference in vertical direction
  let moveX; // touch difference in horizontal direction
  let lastX; // last x
  let lastY; // last y
  let lastXForCapture; // last x for capturing touchmove
  let lastYForCapture; // last y for capturing touchmove

  let lockX; // lock x for prevent scrolling in horizontal direction
  let lockY; // lock y for prevent scrolling in vertical direction
  let clickCount = 0; // number of clicks
  let selectionActive; // true if selection is active
  let lastClickPos = null;
  let teardropDoesShowMenu = true; // teardrop handler
  let teardropTouchEnded = false; // teardrop handler
  let teardropMoveTimeout; // teardrop handler
  let teardropMoveTimeoutX; // teardrop handler
  let forceCursorMode = false; // force to show cursor
  let $activeTeardrop; // active teardrop
  let timeTouchStart; // time of touch start
  let touchEnded = true;
  let threshold = Math.round((1 / devicePixelRatio) * 10) / 20  ;
  let captureLastPos; // last x for capturing touchmove
  var menu_all = false;
  $el.addEventListener('touchstart', touchStart, config, true);
  scroller.addEventListener('contextmenu', contextmenu, config);
  
  editor.setSelection = (value) => {
    selectionActive = value;
  };
  
  editor.setMenu = (value) => {
   // alert("setMenu");
    menuActive = value;
  };
  
  
  
  if (!minimal) {
    editor.on('change', onupdate);
    editor.on('changeSession', onchangesession);
    editor.on('scroll', onscroll);
    editor.on('fold', onfold);
    editor.on('select-word', () => {
      alert("editor select-word");
      selectionMode($end);
    });
    editor.on('scroll-intoview', () => {
      alert("editor select-intoview");
      if (selectionActive) {
        selectionMode($end);
      } else {
        cursorMode();
      }
    });
  //  alert(116)
 
    
  }
  


//#############################################
/*
点击
长按
滚动
选择

移动坐标
移动指针，处理函数
*/
//#############################################
 
  function showpuls(pageX, pageY ){
  //  alert(138)

 
   // alert(pageX+","+ pageY);
  }
  function isIn($el, cX, cY) {
    const {
      x,
      y,
      left,
      top,
      width: sWidth,
      height: sHeight,
    } = $el.getBoundingClientRect();

    const sx = x || left;
    const sy = y || top;

    return (cX > sx && cX < sx + sWidth
      && cY > sy && cY < sy + sHeight);
  }
  function touchStart(e) {
    const $target = e.target;
    cancelAnimationFrame(scrollAnimationFrame);
    const { clientX, clientY } = e.touches[0];

    if (isIn($start, clientX, clientY)) {
      e.preventDefault();
      teardropHandler($start);
      return;
    }
    

    if (isIn($end, clientX, clientY)) {
      e.preventDefault();
      teardropHandler($end);
      return;
    }

    if (isIn($cursor, clientX, clientY)) {
      e.preventDefault();
      teardropHandler($cursor);
      return;
    }
    if (isIn($plugincursor, clientX, clientY)) {
      e.preventDefault();
    //  alert(194)
      editor.session.insert(editor.getCursorPosition(), "---------------------------------------------------------------------------------")
    
   //   teardropHandler($cursor);
      return;
    }
 
    if (isIn($wrapcursor, clientX, clientY)) {
      e.preventDefault();
    //  alert(194)
    editor.session.insert(editor.getCursorPosition(), "\n\n\n")
    
   //   teardropHandler($cursor);
      return;
    }
    
    if ($target.matches(ACE_NO_CURSOR)) {
      moveCursorTo(0, clientY);
      return;
    }
    if ($target.matches(Plugin_icno)) {
      moveCursorTo(0, clientY);
      return;
    }

    touchEnded = false;
    lastX = clientX;
    lastY = clientY;
    lastXForCapture = clientX;
    lastYForCapture = clientY;
    moveY = 0;
    moveX = 0;
    lockX = false;
    lockY = false;
    mode = 'wait';

    setTimeout(() => {
      clickCount = 0;
      lastClickPos = null;
    }, timeToSelectText);

    document.addEventListener('touchmove', touchMove, config);
    document.addEventListener('touchend', touchEnd, config);
  }
  function touchEnd(e) {
    const { clientX, clientY } = e.changedTouches[0];
    // why I was using e.preventDefault() ? 🤔
    // because select word and select line misbehave without
    // preventDefault
    removeListeners();
    touchEnded = true;
 
    if (mode === 'scroll') {
      const scrollX = lockX ? 0 : clientX - lastXForCapture;
      const scrollY = lockY ? 0 : clientY - lastYForCapture;
      scrollAnimation(scrollX, scrollY);
      return;
    }

   
    if (mode === 'wait') {
      if (lastClickPos) {
        const {
          clientX: clickXThen,
          clientY: clickYThen,
        } = lastClickPos;
        const {
          row: rowNow,
          column: columnNow,
        } = renderer.screenToTextCoordinates(clientX, clientY);
        const {
          row: rowThen,
          column: columnThen,
        } = renderer.screenToTextCoordinates(clickXThen, clickYThen);

        const rowDiff = Math.abs(rowNow - rowThen);
        const columnDiff = Math.abs(columnNow - columnThen);
        if (!rowDiff && columnDiff <= 2) {
          clickCount += 1;
        }
      } else {
        clickCount = 1;
      }
      lastClickPos = { clientX, clientY };

      if (clickCount === 2) {
        mode = 'selection';
      } else if (clickCount >= 3) {
        mode = 'select-line';
      } else {
        mode = 'cursor';
      }
    }

    
    if (mode === 'cursor') {
 
      e.preventDefault();
      
       const shiftKey = tag.get('#shift-key');
       if (shiftKey && shiftKey.getAttribute('data-state') === 'on') {
       
        moveCursorTo(clientX, clientY,true);
       }
       else{
        moveCursorTo(clientX, clientY);
       editor.blur();
       //this code important, waste my 1 day
       editor.focus();
        forceCursorMode = true;
        cursorMode();     
       }
      

      
      if (!editor.isFocused()){
        editor.focus();
      }
      
      return;
    }
    
     
    if (mode === 'selection') {
      e.preventDefault();
      moveCursorTo(clientX, clientY);
      select();
      return;
    }
    if (mode === 'select-line') {
      e.preventDefault();
      moveCursorTo(clientX, clientY);
      editor.selection.selectLine();
      select();
    }
   
  }

  function contextmenu(e) {
    e.preventDefault();
    e.stopPropagation();
    if (minimal) return;
    const { clientX, clientY } = e;
    moveCursorTo(clientX, clientY);
    select();
    selectionMode($end);
    editor.focus();
  }



  function touchMove(e) {
   // for scrool
    if (mode === 'selection') {
      removeListeners();
      return;
    }
    let { clientX, clientY } = e.touches[0];
    clientX = Math.round(clientX * 100) / 100;
    clientY = Math.round(clientY * 100) / 100;

    moveX = clientX - lastX;
    moveY = clientY - lastY;
    lastX = clientX;
    lastY = clientY;

    captureLastPos = setTimeout(() => {
      lastXForCapture = clientX;
      lastYForCapture = clientY;
    }, SCROLL_CAPTURE_TIME);


    if (!moveX && !moveY) {
      return;
    }

    if (!false && !lockX && !lockY) {
      if (Math.abs(moveX) > Math.abs(moveY)) {
        lockY = true;
      } else {
        lockX = true;
      }
    }

    if (lockX || Math.abs(moveX) < threshold) {
      moveX = 0;
    }

    if (lockY || Math.abs(moveY) < threshold) {
      moveY = 0;
    }

    if (moveX || moveY) {
      e.preventDefault();
     // [moveX, moveY] = testScroll(moveX, moveY);
      mode = 'scroll';
      scroll(moveX, moveY);
    }
    
  }
  function scroll(x, y) {
    let direction = false ? 1 : -1;
    let scrollX = direction * x;
    let scrollY = direction * y;

    renderer.scrollBy(scrollX, scrollY);
  }
  function scrollAnimation(moveX, moveY) {
   
    const nextX = moveX * 0.01;
    const nextY = moveY * 0.01;

    let scrollX = parseInt(nextX * 100) / 100;
    let scrollY = parseInt(nextY * 100) / 100;


    if (!scrollX && !scrollY) {
      cancelAnimationFrame(scrollAnimationFrame);
      return;
    }

    scroll(moveX, moveY);
    moveX -= scrollX;
    moveY -= scrollY;

    scrollAnimationFrame = requestAnimationFrame(
      scrollAnimation.bind(null, moveX, moveY),
    );
  }
  function testScroll(moveX, moveY) {
    const UP = reverseScrolling ? 'down' : 'up';
    const DOWN = reverseScrolling ? 'up' : 'down';
    const LEFT = reverseScrolling ? 'right' : 'left';
    const RIGHT = reverseScrolling ? 'left' : 'right';

    const vDirection = moveY > 0 ? DOWN : UP;
    const hDirection = moveX > 0 ? RIGHT : LEFT;

    const { getEditorHeight, getEditorWidth } = editorManager;
    // Why I used it in first place?
    // const { scrollLeft } = editor.renderer.scrollBarH;
    const scrollLeft = editor.renderer.getScrollLeft();
    // const { scrollTop } = editor.renderer.scrollBarV;
    const scrollTop = editor.renderer.getScrollTop();
    const [editorWidth, editorHeight] = [getEditorWidth(editor), getEditorHeight(editor)];

    if (
      (vDirection === 'down' && scrollTop <= 0)
      || (vDirection === 'up' && scrollTop >= editorHeight)
    ) {
      moveY = 0;
    }

    if (
      (hDirection === 'right' && scrollLeft <= 0)
      || (hDirection === 'left' && scrollLeft >= editorWidth)
    ) {
      moveX = 0;
    }


    return [moveX, moveY];
  }



  
  function select() {
    removeListeners();
 
    const range =  editor.selection.getWordRange();
    if (!range || range?.isEmpty()) return;
    editor.selection.setSelectionRange(range);
    selectionMode($end);
  }
  function selectionMode($trigger) {
   // if (!teardropSize) return;
    
    clearCursorMode();
    selectionActive = true;
    positionEnd();
    positionStart();
    
    if ($trigger) showMenu($trigger);

    setTimeout(() => {
      editor.selection.on('changeSelection', clearSelectionMode);
      editor.selection.on('changeCursor', clearSelectionMode);
    }, 0);
  }
  function positionStart() {
    const range = editor.getSelectionRange();
    const { pageX, pageY } = renderer.textToScreenCoordinates(range.start);
    const { lineHeight } = renderer;
    const [x, y] = relativePosition(pageX - 30, pageY + lineHeight);


    $start.style.left = `${x}px`;
    $start.style.top = `${y}px`;

    if (!$start.isConnected) $el.append($start);
  }
  function positionEnd() {
    const range = editor.getSelectionRange();
    const { pageX, pageY } = renderer.textToScreenCoordinates(range.end);
    const { lineHeight } = renderer;
    const [x, y] = relativePosition(pageX, pageY + lineHeight);

    $end.style.left = `${x}px`;
    $end.style.top = `${y}px`;

    if (!$end.isConnected) $el.append($end);
  }
  function clearCursorMode() {
    if (!$el.contains($cursor)) return;
    if ($cursor.dataset.immortal === 'true') return;
    $cursor.remove();
    $plugincursor.remove();
    $wrapcursor.remove();
    clearTimeout($cursor.dataset.timeout);

    editor.selection.off('changeCursor', clearCursorMode);
  }
  function clearSelectionMode(e, clearActive = true) {
    const $els = [$start.dataset.immortal, $end.dataset.immortal];
    if ($els.includes('true')) return;
    if ($el.contains($start)) $start.remove();
    if ($el.contains($end)) $end.remove();
    if (clearActive) {
      selectionActive = false;
    }

    editor.selection.off('changeSelection', clearSelectionMode);
    editor.selection.off('changeCursor', clearSelectionMode);
  }
  

  function moveCursorTo(x, y, shiftKey = false, ctrlKey = false) {

    const pos = renderer.screenToTextCoordinates(x, y);
 
 //   hideTooltip();

    if (shiftKey) {
      const anchor = editor.selection.getSelectionAnchor() || editor.getCursorPosition();
      editor.selection.setRange({ start: anchor, end: pos });
      selectionMode($end);
      return;
    }

//Moves the selection cursor to the row and column indicated by pos.
    editor.selection.moveToPosition(pos);
  }
  function cursorMode() {


    if ((!30 || !editor.isFocused()) && !forceCursorMode) {
      $cursor.remove();
      return;
    }

    forceCursorMode = false;
    clearTimeout($cursor.dataset.timeout);
    clearSelectionMode();

    const { pageX, pageY } = renderer.textToScreenCoordinates(
      editor.getCursorPosition()
    );
  // showpuls(pageX, pageY) ;
    const { lineHeight } = renderer;
    const actualHeight = lineHeight;
    const [x, y] = relativePosition(pageX, pageY + actualHeight);
   // alert(pageX+","+x);
    $cursor.style.left = `${x}px`;
    $cursor.style.top = `${y}px`;


    if (!$cursor.isConnected) $el.append($cursor);
    $cursor.startHide();
  
  var line=  editor.getCursorPosition()
  var wholelinetxt = editor.session.getLine(line['row']).trim();
  if(wholelinetxt==''){
    $plugincursor.style.right = "45px";
    $plugincursor.style.top = `${y-actualHeight+1}px`;
    if (!$plugincursor.isConnected) $el.append($plugincursor);

    $wrapcursor.style.right = "85px";
    $wrapcursor.style.top = `${y-actualHeight+1}px`;
    if (!$wrapcursor.isConnected) $el.append($wrapcursor);
  }  

    editor.selection.on('changeCursor', clearCursorMode);
  }

  function teardropHandler($teardrop) {
    $activeTeardrop = $teardrop;
    $activeTeardrop.dataset.immortal = true;
    teardropDoesShowMenu=true;
    teardropTouchEnded = false;

    if (mode === 'cursor') {
      const timeout = parseInt($cursor.dataset.timeout, 10);
      clearTimeout(timeout);
    }

    timeTouchStart = Date.now();
    document.addEventListener('touchmove', teardropTouchMoveHandler, config);
    document.addEventListener('touchend', teardropTouchEndHandler, config);
  }
  function teardropTouchMoveHandler(e) {
    const { clientX, clientY } = e.touches[0];
    const { lineHeight } = renderer;
    const { start, end } = editor.selection.getRange();
    let y = clientY - (lineHeight * 1.8);
    let x = clientX;

    if (timeTouchStart) {
      timeTouchStart = null;

      // Prevents accidental touchmove
      if (diffX < threshold && diffY < threshold) return;

      const diffX = Math.abs(lastX - clientX);
      const diffY = Math.abs(lastY - clientY);
      const timeDiff = Date.now() - timeTouchStart;

      // Prevents accidental touchmove or highly sensitive touchmove
      if (timeDiff < 50) return;
      return;
    }

    if ($activeTeardrop === $cursor) {
      const { row, column } = renderer.screenToTextCoordinates(x, y);
      editor.gotoLine(row + 1, column);
    } else if ($activeTeardrop === $start) {
      x = clientX ;

      const { pageX, pageY } = renderer.textToScreenCoordinates(end);
      if (pageY <= y) {
        y = pageY;
      }

      if (pageY <= y && pageX < x) {
        x = pageX;
      }

      let { row, column } = renderer.screenToTextCoordinates(x, y);

      if (column === end.column) {
        --column;
      }

      editor.selection.setSelectionAnchor(row, column);
      positionEnd();
      positionStart();
    } else {
      const { pageX, pageY } = renderer.textToScreenCoordinates(start);
      if (pageY >= y) {
        y = pageY;
      }

      if (pageY >= y && pageX > x) {
        x = pageX;
      }

      let { row, column } = renderer.screenToTextCoordinates(x, y);

      if (column === start.column) {
     //   ++column;
      }

      editor.selection.moveCursorToPosition({ row, column });
      positionStart();
      positionEnd();
    }
  

    clearTimeout(teardropMoveTimeout);
    clearTimeout(teardropMoveTimeoutX);
    const parent = $el.getBoundingClientRect();
  const scrollThreshold = 20; // Define the distance from the right edge to trigger scrolling
  
    let deltaX = 0;
    let deltaXX = 0;
    if (clientY < parent.top) deltaX = -lineHeight;
    if (clientY > parent.bottom) deltaX = lineHeight;
    
    if (clientX > parent.right - scrollThreshold) {
      deltaXX = 20; // Scroll right by 20px (or adjust as needed)
  //  alert("ggg")
      
    }
   // alert(parent.right)
    if (clientX < parent.left + scrollThreshold + 23 ) {
   //   alert("left")
      deltaXX = -20; // Scroll left by 20px
    }
    if (deltaX) {
      teardropMoveTimeout = setTimeout(() => {
        const top = editor.session.getScrollTop();
        editor.session.setScrollTop(top + deltaX);
        if (teardropTouchEnded) return;
        teardropTouchMoveHandler(e);
      }, 100);
    }
    
  if (deltaXX) {
    //alert(704)
    teardropMoveTimeoutX = setTimeout(() => {
      const left = editor.session.getScrollLeft();
      //alert(704)
      editor.session.setScrollLeft(left + deltaXX);

      if (!teardropTouchEnded) teardropTouchMoveHandler(e);
    }, 100); // Adjust interval as needed
  }
    
    
   //坐标位置是光标的左上角 ，加上高度正好等于文字下面
//        const [x, y] = relativePosition(pageX, pageY + actualHeight);
 //   $cursor.style.left = `${x}px`;
//    $cursor.style.top = `${y}px`;
//摸的是图案，减法==初期位置
   if ($activeTeardrop === $cursor) {
    const [left, top] = relativePosition(clientX, clientY - lineHeight);
    $activeTeardrop.style.left = `${left}px`;
    $activeTeardrop.style.top = `${top}px`;
   }
  }
  function teardropTouchEndHandler() {
    teardropTouchEnded = true;
    if ($activeTeardrop === $cursor) {
      cursorMode();
    } 
    else {
      selectionMode($activeTeardrop);
    }

    $activeTeardrop.dataset.immortal = false;
    document.removeEventListener('touchmove', teardropTouchMoveHandler, config);
    document.removeEventListener('touchend', teardropTouchEndHandler, config);
    
    if (teardropDoesShowMenu) {
      showMenu($activeTeardrop);
    }
    
    editor.focus();
  }
  
  
  //------------------------

  function relativePosition(x, y) {
    const { top, left } = $el.getBoundingClientRect();
    return [x - left, y - top];
  }

  function populateMenuItems(mode = 'regular') {
    $menu.innerHTML = '';
    const copyText = editor.getCopyText();

    const items = [];

  const $copy = tag('span', {
        className: 'icon copy',
        innerHTML:'copy'
    });
  const $cut = tag('span', {
        className: 'icon cut',
        
        innerHTML:'cut'
    });
  const $paste = tag('span', {
        className: 'icon paste',
        innerHTML:'paste'
    });
  const $selectall = tag('span', {
        className: 'icon text_format',
        innerHTML:'all'
    });
    
  const exec = (command) => {
   // alert(command)
 //   e.stopPropagation()
 if (command === 'selectall') {
    editor.selection.off('changeCursor', hideMenu);
    editor.selection.off('changeSelection', hideMenu);
    
    menu_all=true
  }
  editor.execCommand(command);
  if (command === 'copy'){
    hideMenu();
  }

  
  editor.focus();
  if (command === 'selectall') {
    editor.selection.on('changeCursor', hideMenu);
    editor.selection.on('changeSelection', hideMenu);
    
    menu_all=false
  }
};
   const menu_items = [ { onclick: () => exec('copy'),
        text:$copy,
        mode:'selected',
        readOnly:true 
     },
     { onclick: () => exec('cut'),
        text:$cut,
        mode:'selected',
        readOnly:false 
     },
     { onclick: () => exec('paste'),
        text:$paste,
        mode:'all',
        readOnly:false 
     },
     { onclick: () => exec('selectall'),
        text:$selectall,
        mode:'all',
        readOnly:true 
     }]


    menu_items.forEach((item) => {
      if (mode === 'read-only' && !item.readOnly) return;
      if (copyText && !['selected', 'all'].includes(item.mode)) return;
      if (!copyText && item.mode === 'selected') return;

      items.push(item);
    });
  // alert(JSON.stringify(items));
    items.forEach(({ onclick, text }) => {
      const $div_item = tag('div', {
        onclick: onclick
      });
     
      $div_item.appendChild(text);
      $menu.append(
        $div_item
      );
    });
  }
  function positionMenu($trigger) {
    const getProp = ($el, prop) => $el.getBoundingClientRect()[prop];
    const containerRight = getProp($el, 'right');
    const containerLeft = getProp($el, 'left');
    const containerBottom = getProp($el, 'bottom');
    const { lineHeight } = editor.renderer;
    const margin = 10;


    // if menu is positioned off screen horizontally from the right
    const menuRight = getProp($menu, 'right');
    if (menuRight + margin > containerRight) {
      const menuLeft = getProp($menu, 'left');
      const [x] = relativePosition(menuLeft - Math.abs(menuRight - containerRight));
      $menu.style.left = `${x - margin}px`;
    }

    // if menu is positioned off screen horizontally from the left
    const menuLeft = getProp($menu, 'left');
    if (menuLeft - margin < containerLeft) {
      const [x] = relativePosition(menuLeft + Math.abs(menuLeft - containerLeft));
      $menu.style.left = `${x + margin}px`;
    }

    if (shrink()) return;

    // if menu is positioned off screen vertically from the bottom
    const menuBottom = getProp($menu, 'bottom');
    if (menuBottom > containerBottom) {
      const range = editor.getSelectionRange();
      let pos;

      if ($trigger === $start) {
        pos = range.start;
      } else {
        pos = range.end;
      }

      const { pageY } = renderer.textToScreenCoordinates(pos);
      const [, y] = relativePosition(null, pageY - lineHeight * 1.8);
      $menu.style.top = `${y}px`;
    }

    function shrink() {
      const [left, right] = [getProp($menu, 'left'), getProp($menu, 'right')];
      const tooLeft = left < containerLeft;
      const tooRight = right > containerRight;
      if (tooLeft || tooRight) {
        const { scale = 1 } = $menu.dataset;
        $menu.dataset.scale = parseFloat(scale - 0.1);
        $menu.style.transform = `scale(${$menu.dataset.scale})`;
        positionMenu($trigger);
        return true;
      }
      return false;
    }
  }
  
  function removeListeners() {
    document.removeEventListener('touchmove', touchMove, config);
    document.removeEventListener('touchend', touchEnd, config);
  }

   
  function showMenu($trigger) {
    menuActive = true;
    const rect = $trigger?.getBoundingClientRect();
    const { bottom, left } = rect;
    const readOnly = editor.getReadOnly();
    const [x, y] = relativePosition(left, bottom);
    if (readOnly) {
      populateMenuItems('read-only');
    } else {
      populateMenuItems();
    }

    
    $menu.style.left = `${x}px`;
    $menu.style.top = `${y}px`;
    if (!$menu.isConnected) $el.parentElement.append($menu);
    
    if ($trigger) positionMenu($trigger);

    editor.selection.on('changeCursor', hideMenu);
    editor.selection.on('changeSelection', hideMenu);
  //  setTimeout(hideMenu,4400);
    
  }
  function hideMenu(clearActive = true) {
    //alert("hideMenu");
    if (!$el.parentElement.contains($menu)) return;
    $menu.remove();
    editor.selection.off('changeCursor', hideMenu);
    editor.selection.off('changeSelection', hideMenu);
    if (clearActive) menuActive = false;
  }
  


  function onscroll() {
    
    clearTimeout(scrollTimeout);
    clearCursorMode();
   // clearSelectionMode(null, false);
    if(!menu_all){
     // alert("onscroll");
   // hideMenu(false);
    }
   // hideTooltip();
    scrollTimeout = setTimeout(onscrollend, 100);
  }
  
 /*
  function hideTooltip() {
    $gutter.dispatchEvent(new MouseEvent('mouseout'));
  }
  */
  
  function onscrollend() {
    editor._emit('scroll-end');
    
    if (!touchEnded){
      
      return;
      
    }
    
    if (selectionActive) {
      selectionMode();
    }

    if (menuActive) {
      showMenu($end);
    }
    
  }


  function onupdate() {
   // alert("editor onupdate");
    clearSelectionMode();
    clearCursorMode();
    hideMenu();
  }


  function onchangesession() {
   // alert("editor onchangesession");
    cancelAnimationFrame(scrollAnimationFrame);
    setTimeout(() => {
      const copyText = editor.session.getTextRange(editor.getSelectionRange());
      if (copyText) {
       // alert("copyText")
        selectionMode($end);
        return;
      }

      clearSelectionMode();
      cursorMode();
      hideMenu();
    }, 0);
  }


  function onfold() {
  
      clearSelectionMode();
      cursorMode();
      hideMenu();
    
  }

  

  
}



