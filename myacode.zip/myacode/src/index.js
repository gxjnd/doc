import tile from "../components/tile";
import Sidebar from '../components/sidebar';
import contextMenu from '../components/contextMenu';
import sidebarApps from '../sidebarApps';
import tag from 'html-tag-js';
import "html-tag-js/polyfill";
import mustache from 'mustache';
import touchListeners from 'touchHandler';
import EditorManager from 'editorManager';
import fs from './fileSystem/internalFs';
import ws from './fileSystem/write_log';
import fsOperation from './fileSystem/fsOperation';
import helpers from './utils/helpers';
import openFolder from "./openFolder";
import openFile from './openFile';
import quickTools from "./handlers/quickTools";
import arrowkeys from "./handlers/arrowkeys";
import constants from './constants';

import Website from "../components/website";
import newfile from "../components/newfile";
import Settings from "./Settings";
import runPreview from "./runPreview";

import "../styles/page.scss";

import $_menu from '../views/menu.hbs';

let editor;

document.addEventListener('deviceready', onDeviceReady, false);
document.addEventListener("pause", onPause, false);
document.addEventListener("resume", onResume, false);

async function onDeviceReady() {

  StatusBar.overlaysWebView(false)
  StatusBar.styleLightContent();
  StatusBar.backgroundColorByHexString("#9999ff");

  function successHandler(message) {
    //alert('success:'+ message);
  }

  function errorHandler(err) {
    alert('failed' + err);
  }

  var service = 'Echo';
  var action = 'echo';
  var args = [
    'Test Message'
  ];
  //alert(1);
  //cordova.exec(successHandler, errorHandler, service, action, args);
  //alert(2);
  window.app = document.body;

  window.editorManager = {
    files: [],
    activeFile: null
  };
  window.IS_ANDROID_VERSION_5 = device.version;
  window.root = tag.get('#root');

  window.addedFolder = [];
  window.CACHE_STORAGE = cordova.file.externalCacheDirectory || cordova.file.cacheDirectory;

  setTimeout(() => {
    document.body.classList.remove('loading', 'splash');
  }, 50);

  ace.config.set('basePath', './js/ace/');
  window.modelist = ace.require('ace/ext/modelist');

  async function language_File() {
    const languageFile = `${cordova.file.applicationDirectory}www/lang/en-us.json`;
    var str_lang = await fs.readFile(languageFile);
    const uint8Array = new Uint8Array(str_lang.data);
    const text = new TextDecoder("utf-8").decode(uint8Array);
    window.strings = JSON.parse(text);
  }
  await language_File();
  //alert(168)
  window.appSettings = new Settings()
  // alert(169)
  await appSettings.reloadSettings()

  const $toggler = tag('span', {
    className: 'icon menu',
    attr: {
      action: 'toggle-sidebar'
    }
  });

  const $menuToggler = tag("span", {
    className: 'icon more_vert',
    attr: {
      action: 'toggle-menu'
    }
  });

  const $header = tile({
    type: 'header',
    text: 'EF',
    lead: $toggler,
    tail: $menuToggler
  });

  const $footer = tag('footer', {

    id: "quick-tools",

    tabIndex: -1,
    onclick: quickTools.clickListener
  });
  const $lock = tag('span', {
    className: "lock",
    onclick: lock_onclick
  });
  const $unlock = tag('span', {
    className: "unlock",
    onclick: unlock_onclick
  });
  const $playx = tag('span', {
    className: "playx",
    onclick: play_fun
  });
  const $wb = tag('span', {
    className: "website",
    onclick: wb_onclick
  });
  //  alert(mustache.render($_menu, strings))
  const $mainMenu = contextMenu({
    top: '6px',
    right: '6px',
    toggle: $menuToggler,
    transformOrigin: 'top right',
    innerHTML: () => {
      return mustache.render($_menu, strings);
    }
  });
  //alert(158)

  function lock_onclick() {

    var str_name = editorManager.activeFile.filename;
    editorManager.removeFile(editorManager.activeFile);
    var cmd1 = [];
    cmd1.push(str_name);
    cmd1.push("lock");
    cordova.exec(successHandler, errorHandler, service, action, cmd1);

  }

  function unlock_onclick() {

    var cmd2 = [];
    cmd2.push(editorManager.activeFile.filename);
    cmd2.push("unlock");
    cordova.exec(successHandler, errorHandler, service, action, cmd2);

  }
    function play_fun() {
     var file_namex = editorManager.activeFile.filename;

      alert("77")
      alert(file_namex)
      
      webserver.onRequest(
	function(request) {
		console.log("O MA GAWD! This is the request: ", request);

		webserver.sendResponse(
			request.requestId,
			{
				status: 200,
				body: '<html>Hello World</html>',
				headers: {
					'Content-Type': 'text/html'
				}
			}
		);
	}
);

webserver.start();

//... after a long long time
// stop the server
//webserver.stop();
    }

  function wb_onclick() {

    Website()

  }

  const $main = tag('main');

  const $sidebar = Sidebar($main, $toggler);

  const $headerToggler = tag('span', {
    className: 'floating icon keyboard_arrow_left',
    id: "header-toggler"
  });
  const $quickToolToggler = tag('span', {
    className: 'floating icon keyboard_arrow_up',
    id: "quicktool-toggler"
  });

  window.editorManager = await EditorManager($sidebar, $main, $header);
  editor = editorManager.editor;

  const fmode = "click";
  const activationMode = fmode === "long tap" ? "oncontextmenu" : "onclick";
  $headerToggler[activationMode] = function() {
    alert("$headerToggler")
    root.classList.toggle("show-header");
    this.classList.toggle("keyboard_arrow_left");
    this.classList.toggle("keyboard_arrow_right");
  };
  $quickToolToggler[activationMode] = function() {
    // alert("$quickToolToggler")
    quickTools.actions("toggle-quick-tools");
    //  editorManager.controls.vScrollbar.resize();
    //Acode.exec("toggle-quick-tools");
  };

  window.root = tag.get('#root');
  root.append($header);

  root.append($main);
  //alert(216)
  root.append($footer);
  // alert(218)
  if (!true) root.classList.add("hide-floating-button");
  quickTools.actions("enable-quick-tools");
  // alert(221) 
  function set_im() {
    //  const $path_f=cordova.file.externalRootDirectory+"Download/nny/setting.json";

    // const fs = await fsOperation($path_f);

    //  const binData = await fs.readFile();
    // let text = helpers.decodeText(binData);
    var json_eng = appSettings.defaultSettings
    //JSON.parse(text)
    //JSON.parse(text)
    // alert(JSON.stringify(json_eng))
    if (json_eng['showicno'] == true) {
      if (!$lock.isConnected)
        root.append($lock);
      if (!$unlock.isConnected)
        root.append($unlock);
      //if (!$wb.isConnected)
      //   root.append($wb);
    }
    root.append($playx);

  }
  set_im()

  //  alert(244) 

  sidebarApps.init($sidebar);
  sidebarApps.loadApps();
  $footer.addEventListener('touchstart', footerTouchStart);
  $mainMenu.addEventListener('click', handleMenu);

  function handleMenu(e) {

    const $target = e.target;

    const action = $target.getAttribute('action');
    const value = $target.getAttribute('value');
    if (!action) return;
    //alert(action)
    //alert(value)
    if ($mainMenu.contains($target)) $mainMenu.hide();
    // if ($fileMenu.contains($target)) $fileMenu.hide();
    if (action == 'new-file') {
      newfile()
    }
    //Acode.exec(action, value);
  }
  //  alert(254) 

  loadFolders();
  loadFiles();

  editorManager.onupdate = function(doSaveState = true) {

    const activeFile = editorManager.activeFile;
    const $save = $footer.querySelector('[action=save]');

    //    if (!$editMenuToggler.isConnected)
    // $header.insertBefore($editMenuToggler, $header.lastChild);

    if (activeFile) {
      if (activeFile.isUnsaved) {
        activeFile.assocTile.classList.add('notice');
        if ($save) $save.classList.add('notice');
      } else {
        activeFile.assocTile.classList.remove('notice');
        if ($save) $save.classList.remove('notice');
      }

      editorManager.editor.setReadOnly(!activeFile.editable);

    }

    if (doSaveState) saveState();
  };

  function saveState() {
    const lsEditor = [];
    const folders = [];
    const activeFile = editorManager.activeFile;
    const unsaved = [];
    //alert( editorManager.files.length);
    for (let file of editorManager.files) {
      if (file.id === constants.DEFAULT_FILE_SESSION && !file.session.getValue()) continue;
      const edit = {};
      edit.name = file.name;
      edit.type = file.type;
      edit.id = file.id;
      //  alert(file.id)

      if (file.uri) {
        edit.uri = file.uri;
        unsaved.push({
          id: btoa(file.id),
          uri: file.uri
        });
        //  alert(file.uri)
      }

      if (file.isUnsaved) {
        edit.data = file.session.getValue();
      }

      edit.cursorPos = editor.getCursorPosition();
      lsEditor.push(edit);

    }

    // alert(JSON.stringify(lsEditor));
    //alert(unsaved.length);
    unsaved.map(file => {

      const protocol = new URL(file.uri).protocol;
      if (protocol === 'file:') {
        window.resolveLocalFileSystemURL(file.uri, fs => {
          window.resolveLocalFileSystemURL(CACHE_STORAGE, parent => {

            fs.copyTo(parent, file.id);
          }, err => {

          });
        }, err => {

        });
      }
    });

    addedFolder.map(folder => {
      const {
        url,
        reloadOnResume,
        saveState,
        title
      } = folder;
      folders.push({
        url,
        opts: {
          saveState,
          reloadOnResume,
          name: title
        }
      });
    });

    if (activeFile) {
      localStorage.setItem('lastfile', activeFile.id);
    }
    //alert(JSON.stringify(folders));
    localStorage.setItem('files', JSON.stringify(lsEditor));
    localStorage.setItem('folders', JSON.stringify(folders));
  }

  function loadFiles() {

    return new Promise((resolve) => {

      if ('files' in localStorage) {

        const files = helpers.parseJSON(localStorage.getItem('files'));

        if (!files || !files.length) {
          resolve();
          return;
        }

        const lastfile = localStorage.getItem('lastfile') || files.slice(-1)[0].url;
        files.map((file, i) => {
          //alert(file.data);
          const xtra = {
            text: file.data,
            cursorPos: file.cursorPos,
            render: (files.length === 1 || (file.id + '') === lastfile) ? true : false,
            index: i
          };
          //       alert(359);
          //    document.body.setAttribute('data-small-msg', `Loading ${file.name}...`);

          if (file.uri) {
            //  alert(394);

            //alert(file.uri)
            //   alert(JSON.stringify(xtra));
            openFile(file.uri, xtra).then(index => {
              // alert(394);
              if (index === files.length - 1) resolve();
            });

          } else {
            //       alert(403);
            editorManager.addNewFile(file.name, {
              render: xtra.render,
              isUnsaved: !!file.data,
              cursorPos: file.cursorPos,
              text: file.data
            });

            if (i === files.length - 1) resolve();
          }
        });
      } else {
        //alert(415);
        resolve();
      }
    });
  }

  function loadFolders() {
    //alert(JSON.stringify(localStorage.getItem('recentFolders')));

    try {

      const folders = JSON.parse(localStorage.getItem('recentFolders'));
      folders.map(folder => openFolder(folder.url, folder.opts));
    } catch (error) {}
  }

  function footerTouchStart(e) {

    arrowkeys.onTouchStart(e, $footer);

  }
  /*
  function decodeText(arrayBuffer) {

      const uint8Array = new Uint8Array(arrayBuffer);

      return new TextDecoder("utf-8").decode(uint8Array);
  }
  */

  loddjs()

}

async function loddjs() {

  const $ljs = cordova.file.externalRootDirectory + "Download/nny/loadjs.js";

  //const $path_f=cordova.file.externalRootDirectory+"Download/nny/setting.json";

  //const fs = await fsOperation($path_f);

  //const binData = await fs.readFile();
  // let text = helpers.decodeText(binData);

  //  alert(141)
  //const binData = await fs.readFile($ljs);
  //  alert(JSON.stringify(binData))
  // const text = helpers.decodeText(binData);

  const fsx = await fsOperation($ljs);
  const binDatax = await fsx.readFile();
  let text = helpers.decodeText(binDatax);

  // let text = decodeText(binData);
  // alert(await)
  //var json_eng=JSON.parse(text)
  // var hbs_list=get_li(json_eng)
  //   alert(text);
  //    ref.executeScript({code: text}, function () {
  //    alert(text)
  eval(text)
  //  alert("Code Inserted Succesfully");
  //   });

}

async function onResume() {
  await appSettings.reloadSettings()
  var json_eng = appSettings.defaultSettings
  //   alert(JSON.stringify(json_eng))
  // const $path_f=cordova.file.externalRootDirectory+"Download/nny/setting.json";

  //const fs = await fsOperation($path_f);

  //const binData = await fs.readFile();
  //let text = helpers.decodeText(binData);
  //  var json_eng=JSON.parse(text)

  if (json_eng['autopaste'] == true) {

    //  alert("resume")
    var row = editor.session.getLength() - 1

    while (true) {

      var wholelinetxt = editor.session.getLine(row);
      if (wholelinetxt.trim() !== '') {
        break;
      }
      if (row == 0) {
        break;
      }
      row--;
    }

    var column = editor.session.getLine(row).length // or simply Infinity

    editor.gotoLine(row + 1, column)
    //alert(JSON.stringify(line))
    //alert(line['row'])
    const {
      clipboard
    } = cordova.plugins;
    clipboard.paste((text) => {
      if (text == '') {
        return
      }
      var s446 = localStorage.getItem('last_cb')
      if (s446 == text) {
        return;
      }
      localStorage.setItem('last_cb', text);
      editor.session.insert(editor.getCursorPosition(), "\n\n")

      editor.$handlePaste(text);
      editor.session.insert(editor.getCursorPosition(), "\n")

    });

  }
}

function onPause() {
  // alert("Pause");
  /*
        const { clipboard } = cordova.plugins;
       const copyText = editor.getCopyText();
       clipboard.copy(copyText);
     */
}