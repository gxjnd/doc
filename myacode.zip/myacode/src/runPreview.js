import mimeType from 'mime-types';
import fsOperation from './fileSystem/fsOperation';
import Url from './utils/Url';
import path from './utils/path';
import dialogs from '../components/dialogs';

const PORT = 3000;
const MIMETYPE_HTML = mimeType.lookup('html');

/**
 * Runs a preview of an HTML file in a browser.
 * @param {string} htmlPath - Path to the HTML file.
 * @param {"_blank" | "_system"} target - Browser target (in-app or system browser).
 */
async function runPreview(htmlPath, target = appSettings.value.previewMode) {
  // Validate input
  if (!htmlPath || !path.extname(htmlPath).match(/\.html?$/i)) {
    return dialogs.alert('Error', 'Valid HTML file path required.');
  }

  const filename = path.basename(htmlPath);
  const filePath = Url.dirname(htmlPath);

  // Start the server and open the browser
  await startServer({ filename, filePath });
  openBrowser(filename, target);
}

/**
 * Starts the local web server to serve the HTML file.
 * @param {object} config - Configuration object with filename and filePath.
 */
async function startServer({ filename, filePath }) {
  webserver.stop(); // Stop any existing server
  webserver.start(PORT, () => {}, (err) => {
    if (err === 'Server already running') return;
    throw new Error(`Failed to start server: ${err}`);
  });

  webserver.onRequest(async (req) => {
    let reqPath = req.path === '/' ? filename : req.path.substr(1);
    const mime = mimeType.lookup(path.extname(reqPath)) || 'text/plain';

    try {
      if (reqPath === filename) {
        const fileUrl = Url.join(filePath, reqPath);
        await sendHtmlFile(fileUrl, req.requestId);
      } else {
        sendError(req.requestId, `File not found: ${reqPath}`);
      }
    } catch (err) {
      sendError(req.requestId, `File not found: ${reqPath}`);
    }
  });
}

/**
 * Sends HTML file content with injected scripts.
 * @param {string} url - File URL.
 * @param {string} id - Request ID.
 */
async function sendHtmlFile(url, id) {
  const fs = await fsOperation(url);
  let content = await fs.readFile('utf-8');

  // Inject scripts and viewport meta tag
  const scripts = `
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <script src="/editor.js" crossorigin="anonymous"></script>
    <script src="/console.js" crossorigin="anonymous"></script>
    <link rel="stylesheet" href="/console.css">
  `;
  const [head, ...rest] = content.split('<head>');
  if (rest.length) {
    content = `${head}<head>${scripts}${rest.join('<head>')}`;
  } else if (/<html>/i.test(content)) {
    content = content.replace('<html>', `<html><head>${scripts}</head>`);
  } else {
    content = `<head>${scripts}</head>${content}`;
  }

  sendText(content, id, MIMETYPE_HTML);
}

/**
 * Sends text response.
 * @param {string} text - Response body.
 * @param {string} id - Request ID.
 * @param {string} mime - MIME type.
 */
function sendText(text, id, mime) {
  webserver.sendResponse(id, {
    status: 200,
    body: text,
    headers: { 'Content-Type': mime || 'text/html' },
  });
}

/**
 * Sends error response.
 * @param {string} id - Request ID.
 * @param {string} message - Error message.
 */
function sendError(id, message) {
  webserver.sendResponse(id, {
    status: 404,
    body: message,
    headers: { 'Content-Type': 'text/plain' },
  });
}

/**
 * Opens the HTML file in a browser.
 * @param {string} filename - File to open.
 * @param {string} target - Browser target.
 */
function openBrowser(filename, target) {
  const theme = appSettings.value.appTheme;
  const themeData = constants.appThemeList[theme];
  const themeColor = themeData.primary.toUpperCase();
  const textColor = themeData.type === 'dark' || theme === 'default' ? '#ffffff' : '#313131';
  const options = [
    'background=#ffffff',
    'location=yes',
    'hideurlbar=yes',
    'cleardata=yes',
    'clearsessioncache=yes',
    'hardwareback=yes',
    'clearcache=yes',
    `toolbarcolor=${themeColor}`,
    `navigationbuttoncolor=${textColor}`,
    `closebuttoncolor=${textColor}`,
    'zoom=no',
  ].join(',');

  target = target === 'none' ? '_blank' : target === 'browser' ? '_system' : '_blank';
  cordova.InAppBrowser.open(`http://localhost:${PORT}/${filename}`, target, options);
}

/**
 * Checks if the provided file is a runnable HTML file.
 * @param {string} htmlPath - Path to the HTML file.
 * @returns {Promise<string | null>} - File path if runnable, else null.
 */
runPreview.checkRunnable = async (htmlPath) => {
  if (!htmlPath) return null;
  const ext = path.extname(htmlPath).toLowerCase();
  if (!ext.match(/\.html?$/)) return null;

  try {
    const fs = await fsOperation(htmlPath);
    return (await fs.exists()) ? htmlPath : null;
  } catch {
    return null;
  }
};

export default runPreview;