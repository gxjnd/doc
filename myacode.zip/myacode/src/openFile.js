import helpers from "./utils/helpers";
//import dialogs from "../components/dialogs";
import recents from "./recents";
import fsOperation from "./fileSystem/fsOperation";

/**
 * 
 * @param {string|fileOptions} file 
 * @param {object} data
 */
async function open(file, data = {}) {
    
    let name, uri;
 
    if (typeof file === 'object') {
        name = file.name;
        uri = file.uri;
    } else {
        uri = file;
    }
    

    if (!uri) return;

    const fs = await fsOperation(uri);
 //   alert(uri)
 //   alert(26)
    const fileInfo = await fs.stats();
 //  alert(28)
    //const settings = appSettings.value;
    const readOnly = true;
    //fileInfo.canWrite ? false : true;
    const {
        cursorPos,
        render,
        index,
        text
    } = data;

    if (!name) name = fileInfo.name;

    let existingFile;

    if (uri) existingFile = editorManager.getFile(uri, "uri");

    if (existingFile) {
      
        editorManager.switchFile(existingFile.id);
        return index === undefined ? uri : index;
    } 
    else if (text) {
    //  alert("text");
        editorManager.addNewFile(name, {
            uri,
            render,
            text,
            cursorPos,
            isUnsaved: true,
            readOnly
        });
        return index === undefined ? uri : index;
    } 
    
    else {
      
      //alert("null");
        const ext = helpers.extname(name);
        const winLF = /\/r\/n/g;
        let filesNotAllowed = ['zip', 'apk', 'doc', 'docx', 'mp3', 'mp4', 'avi', 'flac', 'mov', 'rar', 'pdf', 'gif', 'flv'];

            
        if (filesNotAllowed.includes((ext || '').toLowerCase())) {
            //dialogs.loader.destroy();
          //  
          return ;
          //alert(strings.notice.toUpperCase(), `'${ext}' ${strings['file is not supported']}`);
        } 

        const binData = await fs.readFile();
        let text = helpers.decodeText(binData);

        editorManager.addNewFile(name, {
            uri,
            cursorPos,//data
            text,//data，true
            isUnsaved: false,
            render,//data
            readonly: readOnly
        });
        
     
        recents.addFile(uri);
      //  alert("else1");
       // alert(JSON.stringify(localStorage));
     
        return index === undefined ? uri : index;
    }
    
    
}

export default function openFile(uri, data = {}) {

    return new Promise((resolve, reject) => {
        
     //   const timeout = setTimeout(() => {
            //dialogs.loader.create(strings.loading + "...");
    //    }, 100);

        open(uri, data)
            .then(resolve)
            .catch(err => {
                //if (data.index !== undefined) resolve(data.index);
               // else reject(err);
            })
            .finally(() => {
            //    clearTimeout(timeout);
                //dialogs.loader.destroy();
            });
    });
}