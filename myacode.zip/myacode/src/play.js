import fsOperation from "./fileSystem/fsOperation";
import helpers from './utils/helpers';

async function loddjs(name) {

  const $ljs = cordova.file.externalRootDirectory + "Download/nny/"+name;
  const fsx = await fsOperation($ljs);
  const binDatax = await fsx.readFile();
  let text = helpers.decodeText(binDatax);
  return text
    
}


async function play(type='') {
  var file_urlx = editorManager.activeFile.uri;
  var file_namex = editorManager.activeFile.name;
  let jsCode="";
  //alert("77")

  //  alert(file_namex)
  if (file_urlx) {
    //  alert(1)
    const fs = await fsOperation(file_urlx);
    //alert(2)
    let content = await fs.readFile('utf-8');
    if (type=="newui"){
     jsCode= await loddjs("newui.js")
    }
    //alert(file_urlx)
    //alert(content)
    
    let text;

    if ((/<html>/i.test(content))) {
      //alert("24")
      text = content;
    } else {
      //alert("27")
      text = `
<!DOCTYPE html>
<html lang="en">
<head>

    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no" />
</head>
<body>
    ${content}
</body>
</html>`;
    }

    webserver.onRequest(
      function(request) {
        //	console.log("O MA GAWD! This is the request: ", request);

        webserver.sendResponse(
          request.requestId, {
            status: 200,
            body: text,
            headers: {
              'Content-Type': 'text/html'
            }
          }
        );
      }
    );
    webserver.stop();
    webserver.start();
    helpers.showToast("running...");

    const options = [
      'background=#ffffff',
      'location=yes',
      'hideurlbar=yes',
      'cleardata=yes',
      'clearsessioncache=yes',
      'hardwareback=yes',
      'clearcache=yes',
      `toolbarcolor=#9999ff`,
      `navigationbuttoncolor=#000000`,
      `closebuttoncolor=#000000`,
      'zoom=no',
    ].join(',');

    //  const options = "location=yes,closebuttoncolor=#000000,zoom=no"

    var ref=cordova.InAppBrowser.open(`http://localhost:8080/${file_namex}`, '_blank', options);
    if (type=="newui"){
   //     alert("newui")
    ref.addEventListener('loadstop', async function(event) {
        
        ref.executeScript({code: jsCode}, function (values) {

        //var name = values[0]; 
   //    alert("ok")
          
        });
    });
    
// 监听从浏览器传回的消息
    ref.addEventListener('message', function (params) {
    // params.data 就是从浏览器传回的对象
    const btnName = params.data.buttonName;
    //console.log("收到的按钮名字是: " + btnName);
    helpers.showToast("点击了按钮: " + btnName);
    });

    }
  }

  //... after a long long time
  // stop the server
  //webserver.stop();
}

export default play;