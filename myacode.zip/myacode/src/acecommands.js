


export function setCommands(editor) {
    const commands = [
      {
  name: 'selectall',
    description: 'Select all',
    exec(editor) {
      editor.selectAll();
    },
    readOnly: true,
  } ,
  
   {
    name: 'copy',
    description: 'Copy',
    exec(editor) {
   //   alert('cp')
      const { clipboard } = cordova.plugins;
      const copyText = editor.getCopyText();
      clipboard.copy(copyText);
      
      
    // plugins.toast.showShortBottom('copied to clipboard');
    },
    readOnly: true,
  },
  
  {
    name: 'cut',
    description: 'Cut',
    exec(editor) {
      let cutLine =
        editor.$copyWithEmptySelection && editor.selection.isEmpty();
      let range = cutLine
        ? editor.selection.getLineRange()
        : editor.selection.getRange();
      editor._emit('cut', range);
      if (!range.isEmpty()) {
        const { clipboard } = cordova.plugins;
        const copyText = editor.session.getTextRange(range);
        clipboard.copy(copyText);
        //plugins.toast.showShortBottom('copied to clipboard');
        editor.session.remove(range);
      }
      editor.clearSelection();
    },
    scrollIntoView: 'cursor',
    multiSelectAction: 'forEach',
  },
  {
    name: 'paste',
    description: 'Paste',
    exec() {
      //alert(2)
      
      const { clipboard } = cordova.plugins;
      clipboard.paste((text) => {
        editor.$handlePaste(text);
      });
      
    },
    scrollIntoView: 'cursor',
  }
    ]
  commands.forEach((command) => {
    //console.log(command)
   // alert(JSON.stringify(command))
    editor.commands.addCommand(command);
  });
  }

