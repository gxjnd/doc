
import FileBrowser from '../fileBrowser/fileBrowser';
import Url from "./utils/Url";
import openFolder from "./openFolder";

/**
 * TODO: Add file to close current and all tab
 */

const commands = {
 
  "open-folder"() {
    //editorManager.editor.blur();
    FileBrowser('folder')
      .then(res => {
        
        const url = res.url;
        const protocol = Url.getProtocol(url);
//alert(url)


          return openFolder(res.url, {
            name: res.name
          });
        

      })
      .then(() => {
        window.plugins.toast.showShortBottom('folder added');        
      //  editorManager.onupdate();
      })
      .catch(err => {
       alert('error')
      });
  }
  
};

export default commands;