import fs from './fileSystem/internalFs';
import fsOperation from './fileSystem/fsOperation';
import helpers from './utils/helpers';



class Settings {
    constructor() {
        this.defaultSettings = {
            caseSensitive: false,
            regExp: false,
            wholeWord: false,
            wrap: false,
            autopaste: false,
           showicno:true,
           stopreplace:true,
           stopreplaceall:true,
           filepath:'',
           extension:['txt','js','kt','html','css','json','py','c'],
           useext:'.txt'
           
            
        };

        this.settingsFilePath = cordova.file.externalRootDirectory+"Download/nny/setting.json";
        
       // this.loadSettings();
    }

    async loadSettings() {
        try {
               const fsx = await fsOperation(this.settingsFilePath);
            //alert(62)
            const res = await fsx.readFile();
            //alert(63)
            const settings = JSON.parse(helpers.decodeText(res));
            //alert(settings)
           // alert(JSON.stringify(settings))
      
           this.mergeSettings(settings);
         //   alert(JSON.stringify(this.defaultSettings))
        } catch (error) {
            console.error("Error loading settings:", error);
        }
    }

    mergeSettings(newSettings) {
        for (const key in newSettings) {
            if (newSettings.hasOwnProperty(key)) {
                this.defaultSettings[key] = newSettings[key];
            }
        }
    }

    update(settings, showToast = true) {
        if (typeof settings === "boolean") {
            showToast = settings;
        } else if (typeof settings === "object") {
            for (const key in settings) {
                if (this.defaultSettings.hasOwnProperty(key)) {
                    this.defaultSettings[key] = settings[key];
                }
            }
        }

        this.saveSettings(showToast);
    }

    async saveSettings(showToast) {
        try {
            await fs.writeFile(this.settingsFilePath, JSON.stringify(this.defaultSettings, null, 4), true, false);
            if (showToast) {
                // plugins.toast.showShortBottom(strings['settings saved']);
            }
        } catch (error) {
            console.error("Error saving settings:", error);
        }
    }
    
    async reloadSettings() {
        await this.loadSettings(); // 重新加载设置
    }
}

export default Settings;
