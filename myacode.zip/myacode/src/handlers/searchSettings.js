import Page from "../../components/page";
import tag from 'html-tag-js';
import fs from '../fileSystem/internalFs';
import EditorManager from '../editorManager';

export default function searchSettings() {
    const page = Page('search');
    const settingsList = tag('div', {
        className: 'main list'
    });

    const values = appSettings.defaultSettings
               //   const search_json=    cordova.file.externalDataDirectory+ 'settings.json'  
                 
    const settingsOptions = [{
            key: 'caseSensitive',
            text: 'Case sensitive',
            checkbox: values.caseSensitive
        },
        {
            key: 'regExp',
            text: 'RegExp',
            checkbox: values.regExp
        },
        {
            key: 'wrap',
            text: 'wrap',
            checkbox: values.wrap
        },
        {
            key: 'wholeWord',
            text: 'Whole word',
            checkbox: values.wholeWord
        },
        {
            key: 'showicno',
            text: 'show lock',
            checkbox: values.showicno
        },
        {
            key: 'autopaste',
            text: 'auto paste',
            checkbox: values.autopaste
        },
        {
            key: 'stopreplace',
            text: 'stop replace',
            checkbox: values.stopreplace
        },
        {
            key: 'stopreplaceall',
            text: 'stop replace all',
            checkbox: values.stopreplaceall
        }
    ];
settingsOptions.forEach(option => {
                const listItem = document.createElement("div");
                listItem.className = "list-item";

                const label = document.createElement("label");
                label.textContent = option.text;

                const checkbox = document.createElement("input");
                checkbox.type = "checkbox";
                checkbox.checked = values[option.key];
                checkbox.addEventListener("change", () => {
                    values[option.key] = checkbox.checked;
                  //alert(JSON.stringify(settings))
 
                 // fs.writeFile(search_json, JSON.stringify(values, undefined, 4), true, false)
                  appSettings.update(values)
                  //  saveSettings();
                });

                listItem.appendChild(label);
                listItem.appendChild(checkbox);
                settingsList.appendChild(listItem);
            });
  //  gen.listItems(settingsList, settingsOptions, changeSetting);
    const tabdiv = tag('div', {
        className: 'tabdiv'
    });
    var tabinput = tag('input', {
    type: 'text',
    id: 'tabinput',
    placeholder: ''
  });
    var tabok = tag('button', {
    className: 'tabokbtn',
    id: 'tabok',
    innerHTML: 'ok'
  });  
    tabdiv.appendChild(tabinput)
    tabdiv.appendChild(tabok)
    settingsList.appendChild(tabdiv);
tabok.onclick = function() {
  
  tabok.classList.add('clicked');
  setTimeout(() => {
      tabok.classList.remove('clicked');
  }, 500); 
//alert(tabinput.value)
values['tab'] = tabinput.value;
appSettings.update(values)



}
    page.appendChild(settingsList);
    document.body.append(page);
}
//---------------------------------------------------------------------------------




  //    writeFile: content => fs.writeFile(url, content, false, false),
