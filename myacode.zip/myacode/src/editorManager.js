import "../styles/page.scss";
import tag from 'html-tag-js';
import "html-tag-js/polyfill";
import ScrollBar from '../components/scrollbar';
import helpers from './utils/helpers';
import internalFs from './fileSystem/internalFs';
import list from '../components/collapsableList';


import tile from "../components/tile";

import Url from './utils/Url';
import path from './utils/path';
import Uri from './utils/Uri';

import touchListeners from 'touchHandler';
import { setCommands } from 'acecommands';

//TODO: Add option to work multiple files at same time in large display.

/**
 *
 * @param {HTMLElement} $header
 * @param {HTMLElement} $body
 */
async function EditorManager($sidebar,$body,$header) {
    
    let $openFileList;
    let editorState = 'blur';
    let ready = false;
    let preventScrollbarV = false;
    let preventScrollbarH = false;
    let lastHeight = innerHeight;
    let checkTimeout = null;
    let TIMEOUT_VALUE = 300;
    const $container = tag('div', {
          className: 'editor-container'
      });
    const editor = ace.edit($container);
    
    const SESSION_DIRNAME = 'sessions';
    const SESSION_PATH = cordova.file.cacheDirectory + SESSION_DIRNAME + '/';
  
     const values = appSettings.defaultSettings
    
    const $vScrollbar = ScrollBar({
      width: 20,
      onscroll: onscrollV,
      onscrollend: onscrollVend,
      parent: $body,
    });
    const $hScrollbar = ScrollBar({
      width: 20,
      onscroll: onscrollH,
      onscrollend: onscrollHEnd,
      parent: $body,
      placement: 'bottom',
    });
    
    const manager = {
      editor,
      addNewFile,
      getFile,
      removeFile,
      switchFile,
      onFileSave,
      activeFile: null,
      moveOpenFileList,
      files: [],
      getEditorHeight,
      getEditorWidth,
      onupdate: () => {},
      get state() {
        return editorState;
      },
      sidebar: $sidebar
    }
    
    moveOpenFileList();
    $body.appendChild($container);
    
    window.addEventListener('resize', () => {

        if (innerHeight > lastHeight) {

            editor.blur();
            editorState = 'blur';
        }
        lastHeight = innerHeight;
        editor.renderer.scrollCursorIntoView();
    });
    editor.on('focus', () => {
        editorState = 'focus';
     //   alert("focus");
        $hScrollbar.hide();
        $vScrollbar.hide();
    });
 
    editor.on('change', function (e) {

        if (checkTimeout) clearTimeout(checkTimeout);

        checkTimeout = setTimeout(() => {
            checkChanges()
                .then(res => {
                    if (!res) manager.activeFile.isUnsaved = true;
                    else manager.activeFile.isUnsaved = false;
                    manager.onupdate();
                });
        }, TIMEOUT_VALUE);
    });
 
 
     addNewFile("untitled.txt", {

        isUnsaved: false,

        render: true,
        id:  "default-session"
    });
 
 
     //----------------





    editor.session.on('changeScrollTop', class_onscrolltop);
    function class_onscrolltop(e) {
      editor._emit('scrolltop', e);
    }
    
    editor.session.on('changeScrollLeft', class_onscrollleft);
    function class_onscrollleft(e) {
      editor._emit('scrollleft', e);
    }
  
    editor.on('scrolltop', onscrolltop);
    editor.on('scrollleft', onscrollleft);
    
    function onscrolltop(render = true) {

     if (preventScrollbarV) {
      // alert("preventScrollbarV");
       return;
     }
        const session = editor.getSession();
        const editorHeight = getEditorHeight(editor);
        const factor = (session.getScrollTop() / editorHeight).toFixed(2);
        $vScrollbar.value = factor;
      
        if (render) $vScrollbar.render();
      editor._emit('scroll', 'vertical');
   
    }
    function onscrollleft(render = true) {
     if (preventScrollbarH) return;

        const session = editor.getSession();

        const editorWidth = getEditorWidth(editor);

        const factor = (session.getScrollLeft() / editorWidth).toFixed(2);

    //    console.log(factor);
        $hScrollbar.value = factor;
      if (render) $hScrollbar.render();
       editor._emit('scroll', 'horizontal');
    }

    //----------------
    touchListeners(editor);
 
 
    
    function onscrollH(value) {
      preventScrollbarH = true;
      const session = editor.getSession();
      const editorWidth = getEditorWidth(editor);
      const scroll = editorWidth * value;
  
      session.setScrollLeft(scroll);
      editor._emit('scroll', editor);
      cancelAnimationFrame(scrollAnimationFrame);
    }
    function onscrollHEnd() {
      preventScrollbarH = false;
    }
    function onscrollV(value) {
      preventScrollbarV = true;
      const session = editor.getSession();
      const editorHeight = getEditorHeight(editor);
      const scroll = editorHeight * value;
  
      session.setScrollTop(scroll);
      editor._emit('scroll', editor);
      cancelAnimationFrame(scrollAnimationFrame);
    }
    function onscrollVend() {
      preventScrollbarV = false;
    }
    function getEditorHeight(editor) {
      const { renderer, session } = editor;
      const offset = (renderer.$size.scrollerHeight + renderer.lineHeight) * 0.5;
      const editorHeight = session.getScreenLength() * renderer.lineHeight - offset;
      return editorHeight;
    }
    function getEditorWidth(editor) {
      const { renderer, session } = editor;
      const offset = renderer.$size.scrollerWidth - renderer.characterWidth;
      const editorWidth = session.getScreenWidth() * renderer.characterWidth - offset;
      if (false) {
        return editorWidth;
      } else {
        return editorWidth + 50;
      }
    }
  
    setCommands(editor);
  
    window.resolveLocalFileSystemURL(SESSION_PATH, () => {
      ready = true; 
    /*     emptyQueue();*/
    }, () => {
      internalFs.createDir(cordova.file.cacheDirectory, SESSION_DIRNAME)
          .then(() => {
              ready = true;
            //  emptyQueue();
          });
  });


  
  
    function moveOpenFileList() {
        let $list;

        if ($openFileList) {
            if ($openFileList.classList.contains('collaspable')) {
                $list = [...$openFileList.$ul.children];
            } else {
                $list = [...$openFileList.children];
            }
            $openFileList.remove();
        }

        if ('header' === 'header') {
            $openFileList = tag('ul', {
                className: 'open-file-list'
              //  ontouchstart: checkForDrag,
            //    onmousedown: checkForDrag
            });
            if ($list) $openFileList.append(...$list);
            root.append($openFileList);
            root.classList.add('top-bar');
        } else {
          /*
            $openFileList = list('active files');
            $openFileList.ontoggle = function () {
                openFolder.updateHeight();
            };
            if ($list) $openFileList.$ul.append(...$list);
            $sidebar.insertBefore($openFileList, $sidebar.firstElementChild);
            root.classList.remove('top-bar');
        
        */
          
        }
    }
    
    function removeFile(id, force) {

        /**

         * @type {File}
         */
        const file = typeof id === "string" ? getFile(id, "id") : id;

        if (!file) return;

        if (file.isUnsaved && !force) {
          //  dialogs.confirm(strings.warning.toUpperCase(), strings['unsaved file']).then(closeFile);
          closeFile();
        } else {
            closeFile();

         //   if (file.type === 'git') gitRecord.remove(file.record.sha);
     //       else if (file.type === 'gist') gistRecord.remove(file.record);
        }

        function closeFile() {
            manager.files = manager.files.filter(editor => editor.id !== file.id);

            if (!manager.files.length) {
                editor.setSession(new ace.EditSession(""));
                $sidebar.hide();
                addNewFile('untitled.txt', {
                    isUnsaved: false,
                    render: true,
                    id:  "default-session"
                });
            } else {
                if (file.id === manager.activeFile.id) {
                    switchFile(manager.files[manager.files.length - 1].id);
                }
            }

            file.session.off("changeScrollTop", onscrolltop);
        //    if (!appSettings.value.textWrap)
            file.session.off("changeScrollLeft", onscrollleft);
              /*
                if ('recentFiles' in localStorage) {
                  const files = JSON.parse(localStorage.getItem('recentFiles'));
                  var new_file = files.filter(filee => {
                      if(!(filee.includes(file.assocTile.text))){
                        return filee;
                      }
                      
                    });
                  localStorage.recentFiles = JSON.stringify(new_file);
                }
                */
          
           // alert(JSON.stringify(file.assocTile.text));
        //    alert(JSON.stringify(manager));
            file.assocTile.remove();
            
            file.session.destroy();
            delete file.session;
            delete file.assocTile;
            manager.onupdate();
        }
    }

    function getFile(checkFor, type = "id") {

        if (typeof type !== "string") return null;
       //  if (typeof checkFor === 'string' && !["id" | "name"].includes(type)) checkFor = decodeURL(checkFor);

        let result = null;
        
        for (let file of manager.files) {
            if (typeof type === "string") {

                if (type === "id" && file.id === checkFor) {
           //     alert(1);
                result = file;
                }
                else if (type === "name" && file.name === checkFor) result = file;
                else if (type === "uri" && file.uri === checkFor) result = file;
                else if (type === "gist" && file.record && file.record.id === checkFor.id) result = file;
                else if (type === "git" && file.record && file.record.sha === checkFor.sha) result = file;

            }
            if (result) break;

        }
        
        return result;
    }

    function addNewFile(filename, options = {}) {
        
        /*if (!ready) {
            queue.push({
                filename,
                options
            });
            return;
        }
*/

        let doesExists = null;

        if (options.id) doesExists = getFile(options.id, "id");
        else if (options.uri) doesExists = getFile(options.uri, "uri");
        else if (options.record) doesExists = getFile(options.record, options.type);

        if (doesExists) {
       //     if (manager.activeFile.id !== doesExists.id) switchFile(doesExists.id);
            return;
        }

        options.isUnsaved = options.isUnsaved === undefined ? true : options.isUnsaved;
        options.render = options.render === undefined ? true : options.render;

        const removeBtn = tag('span', {
            className: 'icon cancel',
            attr: {
                action: ''
            },
            onclick: () => {
           
                removeFile(file);
            }
        });

        const assocTile = tile({
            lead: tag('li', {
                className: helpers.getIconForFile(filename),
            }),
            text: filename,
            tail: removeBtn
        });
        const text = options.text || '';
        let id = options.id || helpers.uuid();
        
        let file = {
            id,
            sessionCreated: false,
            controls: false,
            
            session: ace.createEditSession(text),
            uri: options.uri,
            name: filename,
            editable: true,
            type: options.type || 'regular',
            isUnsaved: options.isUnsaved,
            record: options.record,
            encoding: 'utf-8',
            assocTile,
            
            readOnly: options.readonly === undefined ? false : options.readonly,
         
         
           setMode(mode) {
                this.session.setMode(mode);
             //   const filemode = modelist.getModeForPath(this.filename).mode;
                let tmpFileName;

               // if (mode !== filemode) {
                  /*
                    const modeName = mode.split('/').slice(-1)[0];
                    const exts = modelist.modesByName[modeName].extensions.split("|");
                    const filename = path.parse(this.filename).name;

                    for (let ext of exts) {
                        if (/[a-z0-9]/.test(ext)) {
                            tmpFileName = filename + "." + ext;
                            break;
                        }
                    }
                    if (!tmpFileName) tmpFileName = filename + '.txt';
                  */
            //    }
             //   else {
                   // tmpFileName = this.filename;
           //     }
                /*
                this.assocTile.lead(tag('i', {
                    className: helpers.getIconForFile(tmpFileName),
                    style: {
                        paddingRight: '5px'
                    }
                }));
                */
            },
            

            get filename() {
                if (this.type === 'git') return this.record.name;
                else return this.name;
            },
                        /*,
            set filename(name) {
                changeName.call(this, name);
            },
            */
            get location() {
                if (this.uri)
                    try {
                        return Url.dirname(this.uri);
                    } catch (error) {
                        return null;
                    }
                return null;
            }
            /*,
            set location(url) {
                if (this.readOnly) this.readOnly = false;

                if (url) this.uri = Url.join(url, this.filename);
                else this.uri = null;

                setSubText(this);
                manager.onupdate();
            },*/
            

        
        };
        


        if (options.isUnsaved && !options.readOnly)
            file.assocTile.classList.add('notice');

        file.assocTile.classList.add('light');

        file.assocTile.addEventListener('click', function (e) {

            if (manager.activeFile &&(e.target === removeBtn || manager.activeFile.id === file.id)) return;

            $sidebar.hide();
            switchFile(file.id);
        });

        
        
        manager.files.push(file);

 

        if ('header' === 'header')
            $openFileList.append(file.assocTile);

/*
        else
            $openFileList.$ul.append(file.assocTile);
*/

        createSession(text || ""); 

    
        
       setupSession(file);
       if (options.render) {
          
            switchFile(file.id);

            /*if (options.cursorPos)
                editor.moveCursorToPosition(options.cursorPos);
            */
            if (file.id !== "default-session") {
                const defaultFile = getFile("default-session", "id");
                if (defaultFile) {
                    const value = !!defaultFile.session.getValue();
                    const renamed = defaultFile.name !== "untitled.txt";
                   // alert("renamed"+","+defaultFile.name);
                    if (!value && !renamed) manager.removeFile(defaultFile);
                }
            }
        }

        setTimeout(() => {
            editor.resize(true);
        }, 0);

        file.session.on("changeScrollTop", onscrolltop);
        if (!false)
            file.session.on("changeScrollLeft", onscrollleft);


        function createSession(text) {
            internalFs.writeFile(SESSION_PATH + id, text, true, false)
                .then(() => {
                    file.sessionCreated = true;
                })
                .catch(err => {
                    console.log(err);
                });
        }

        return file;
    }

    function switchFile(id) {
        for (let file of manager.files) {
            if (id === file.id) {
       
                if (manager.activeFile) {
                    manager.activeFile.assocTile.classList.remove('active');
                }
        
                editor.setSession(file.session);
                if (manager.state === 'focus') editor.focus();
              //  setTimeout(controls.update, 100);

                $header.text=file.name;
                setSubText(file);
                file.assocTile.classList.add('active');
                manager.activeFile = file;
                manager.onupdate();

                //file.assocTile.scrollIntoView();

                $hScrollbar.remove();
                $vScrollbar.remove();
                onscrolltop(false);
            //    if (!appSettings.value.textWrap) onscrollleft(false);
                return;
            }
        }

        manager.onupdate(false);
    }

    function setSubText(file) {
//alert(599)
        let text = file.location;


        if (file.type === 'git') {
            //text = 'git • ' + file.record.repo + '/' + file.record.path;
        } else if (file.type === 'gist') {
           // const id = file.record.id;
            //text = 'gist • ' + (id.length > 10 ? '...' + id.substring(id.length - 7) : id);
        } else if (text) {

            //const protocol = Url.getProtocol(text);
           // if (protocol === "content:") text = Uri.getVirtualAddress(text);
           // else text = Url.parse(text).url;

            if (text.length > 30) text = '...' + text.slice(text.length - 27);

        } else if (file.readOnly) {
            text = 'read only';
        } else {
            text = 'new file';
        }
        //alert(text)
        $header.subText=text;
    }





    function setupSession(file) {

        const session = file.session;

        const filename = file.name;
        const ext = path.extname(filename);
        let mode;

        try {
            const modes = JSON.parse(localStorage.modeassoc || '{}');
            const ext = path.extname(filename);
            if (ext in modes) {
              mode = modes[ext];
            }
            else{ 
              throw new Error("Mode not found");
            }
        } catch (error) {

            mode = modelist.getModeForPath(filename).mode;
          
        }

        let useWorker = false;

        if (ext === ".jsx")
            useWorker = false;

        session.setOption("useWorker", useWorker);
        

        if (file.session.$modeId !== mode) {

            if (mode === "ace/mode/text") {
                editor.setOptions({
                    enableBasicAutocompletion: false,
                    enableSnippets: false,
                    enableLiveAutocompletion: false
                });
            } else {
             // alert(mode)
                editor.setOptions({
                    enableBasicAutocompletion: true,
                    enableSnippets: true,
                    enableLiveAutocompletion:true
                });
            }
            
            session.setOptions({
                tabSize: parseInt(values.tab, 10) || 2,
                useSoftTabs: true
            });
            file.setMode(mode);
        }
        
        file.session.setUseWrapMode(false);
    }

    function checkChanges(write) {

        const file = SESSION_PATH + manager.activeFile.id;

        const text = manager.activeFile.session.getValue();
        const activeFile = manager.activeFile;
        return new Promise((resolve, reject) => {
            if (activeFile && activeFile.sessionCreated) {
                internalFs.readFile(file)
                    .then(res => {
                        const old_text = helpers.decodeText(res.data);
                        if (old_text !== text)
                            resolve(false);
                        else
                            resolve(true);
                    })
                    .catch(reject)
                    .finally(() => {
                        if (write) internalFs.writeFile(file, text, true, false);
                    });
            }
        });
    }

    function onFileSave(file) {

        internalFs.writeFile(SESSION_PATH + file.id, file.session.getValue(), true, false);

    }



    editor.setFontSize("14px");
    editor.setTheme("ace/theme/github");
 
    editor.container.style.lineHeight = 1.6;
    editor.setHighlightSelectedWord(true);
           //      enableEmmet: true,
    editor.setOptions({
              animatedScroll: false,
              tooltipFollowsMouse: false,
              showGutter: true,
              showLineNumbers: true,

              showInvisibles: false,
              indentedSoftWrap: false,
              scrollPastEnd: 0.5,
              showPrintMargin: false
          });
    editor.renderer.setMargin(0, 0, -16, 0);

    return manager;
  
}

export default EditorManager;

        //      enableEmmet: true,
