import ajax from '../utils/ajax';
import Url from '../utils/Url';
import mimeType from 'mime-types';
export default {

    /**
     * 
     * @param {string} url 
     * @returns {Promise}
     */
    listDir(url) {
        // url = decodeURL(url);
        return new Promise((resolve, reject) => {
            window.resolveLocalFileSystemURL(url, success, reject);

            function success(fs) {
                const reader = fs.createReader();
                reader.readEntries(resolve, reject);
            }
        });
    },

    /**
     * 
     * @param {string} filename 
     * @param {any} data
     * @param {boolean} create If this property is true, and the requested file or 
     * directory doesn't exist, the user agent should create it. 
     * The default is false. The parent directory must already exist.
     * @param {boolean} exclusive If true, and the create option is also true, 
     * the file must not exist prior to issuing the call. 
     * Instead, it must be possible for it to be created newly at call time. The default is false.
     * @returns {Promise} 
     */
    writeFile(filename, data, create = false, exclusive = true) {
        // filename = decodeURL(filename);
        const name = filename.split('/').pop();
        const _path = Url.dirname(filename);
        return new Promise((resolve, reject) => {
            if (!create) {
                window.resolveLocalFileSystemURL(filename, fileEntry => {
                    if (!fileEntry.isFile) reject('Expected file but got directory.');
                    fileEntry.createWriter(file => {
                        file.onwriteend = () => resolve(filename);
                        file.onerror = (err) => reject(err.target.error);
                        file.write(data);
                    });
                }, reject);
            } else {
                window.resolveLocalFileSystemURL(_path, fs => {
                    fs.getFile(name, {
                        create,
                        exclusive: create ? exclusive : false
                    }, fileEntry => {
                        fileEntry.createWriter(file => {
                            file.onwriteend = () => resolve(filename);
                            file.onerror = (err) => reject(err.target.error);
                            file.write(data);
                        });
                    }, reject);
                }, reject);
            }
        });
    },

    /**
     * 
     * @param {string} filename
     * @returns {Promise} 
     */
    deleteFile(filename) {
        // filename = decodeURL(filename);
        return new Promise((resolve, reject) => {
            window.resolveLocalFileSystemURL(filename, entry => {
                if (entry.isFile) {
                    entry.remove(resolve, reject);
                } else {
                    entry.removeRecursively(resolve, reject);
                }
            }, reject);
        });
    },

    /**
     * 
     * @param {string} filename
     * @returns {Promise} 
     */
    readFile(filename) {
        // filename = decodeURL(filename);
        return new Promise((resolve, reject) => {

            if (!filename) return reject("Invalid valud of fileURL: " + filename);

            ajax({
                url: filename,
                responseType: "arraybuffer"
            }).then(res => {
//alert(99)
                if (res)
                {
                  
                    resolve({
                        data: res
                    });
                }
                else
                    return Promise.reject();

            }).catch(() => {
         //     alert(111)
                window.resolveLocalFileSystemURL(filename, fileEntry => {
                    fileEntry.file(file => {
                        const fileReader = new FileReader();
                        fileReader.onloadend = function () {
                            resolve({
                                file,
                                data: this.result
                            });
                        };

                        fileReader.onerror = reject;

                        fileReader.readAsArrayBuffer(file);
                    }, reject);
                }, reject);
            });
        });
    },

    /**
     * 
     * @param {string} url 
     * @param {string} newname
     * @returns {Promise} 
     */
    renameFile(url, newname) {
        // url = decodeURL(url);
        return new Promise((resolve, reject) => {
            window.resolveLocalFileSystemURL(url, fs => {
                fs.getParent(parent => {
                    const parentUrl = decodeURIComponent(parent.nativeURL);
                    const newUrl = Url.join(parentUrl, newname);
                    fs.moveTo(parent, newname, () => resolve(newUrl), reject);
                }, reject);
            }, reject);
        });
    },

    /**
     * 
     * @param {string} path 
     * @param {string} dirname
     * @returns {Promise} 
     */
    createDir(path, dirname) {
        // path = decodeURL(path);
        return new Promise((resolve, reject) => {
            window.resolveLocalFileSystemURL(path, fs => {
                fs.getDirectory(dirname, {
                    create: true
                }, () => resolve(Url.join(path, dirname)), reject);
            }, reject);
        });
    },

    copy(src, dest) {
        return moveOrCopy("copyTo", src, dest);
    },

    move(src, dest) {
        return moveOrCopy("moveTo", src, dest);
    },

    /**
     * 
     * @param {"copyTO"|"moveTo"} action 
     * @param {string} src 
     * @param {string} dest 
     */
    moveOrCopy(action, src, dest) {
        return new Promise((resolve, reject) => {
            //alert("moveOrCopy");
            this.verify(src, dest)
                .then(res => {
                    const {
                        src,
                        dest
                    } = res;
      //        alert("src:"+JSON.stringify(src));
         //     alert("dest:"+JSON.stringify(dest));
                    src[action](dest, undefined, entry => resolve(decodeURIComponent(entry.nativeURL)), reject);
                
                  
                })
                .catch(reject);
        });
    },  

    stats(filename) {
        return new Promise((resolve, reject) => {
            sdcard.stats(filename, stats => {
                stats.uri = filename;
                resolve(stats);
            }, reject);
        });
    },


    /**
     * 
     * @param {string} src 
     * @param {string} dest 
     * @returns {Promise<{src:Entry, dest:Entry}>}
     */
    verify(src, dest) {
        return new Promise((resolve, reject) => {
            window.resolveLocalFileSystemURL(src, srcEntry => {
                window.resolveLocalFileSystemURL(dest, destEntry => {
                    window.resolveLocalFileSystemURL(Url.join(destEntry.nativeURL, srcEntry.name), res => {

                        reject({
                            code: 12
                        });

                    }, err => {
                        if (err.code === 1) {
                         // alert(225)
                            resolve({
                                src: srcEntry,
                                dest: destEntry
                            });
                        } else {
                            reject(err);
                        }

                    });

                }, reject);
            }, reject);
        });
    },

    /**
     * 
     * @param {Promise<Boolean>} url 
     */
    exists(url) {
        return new Promise((resolve, reject) => {
            window.resolveLocalFileSystemURL(url, entry => {
                resolve(true);
            }, err => {
                if (err.code === 1) resolve(false);
                reject(err);
            });
        });
    }

};