

export default{
   writeLog_start(sttr){
    
  var logOb;  
  window.resolveLocalFileSystemURL(cordova.file.externalDataDirectory, function(dir) {
	//	console.log("got main dir",dir);
		dir.getFile("log.txt", {create:true}, function(file) {
	//		console.log("got the file", file);
			logOb = file;
//			alert("jyfg")
			if(!logOb) return;
	

	var log =  sttr;
	//JSON.stringify(tutorials_for_w);
// Expecte
//	var log = str + " [" + (new Date()) + "]\n";

	//console.log("going to log "+log);
	logOb.createWriter(function(fileWriter) {
		
		fileWriter.seek(fileWriter.length);
	//	if(fileWriter.length==0){
		var blob = new Blob([log], {type:'text/plain'});
		fileWriter.write(blob);
	//	console.log("ok, in theory i worked");
	//	}
	  
	}, ()=>{console.log("FileSystem Error");});			
		});
		
		
	});
	

  
}




//alert("logOb")
//fs.writeFile(cordova.file.externalDataDirectory+".log.txt","utfjfjffjfff");
 
     
     
 // const log_f = `${cordova.file.externalDataDirectory}log.txt`;
}