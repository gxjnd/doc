import tag from 'html-tag-js';
import fsOperation from './fileSystem/fsOperation';
import collapsableList from '../components/collapsableList';
import helpers from './utils/helpers';
import dialogs from '../components/dialogs';
import tile from '../components/tile';
import constants from './constants';
import recents from './recents';
import path from './utils/path';
import openFile from './openFile';
import Url from './utils/Url';

//---
/**
//--- * 
//--- * @param {string} _path
//--- * @param {object} [opts]
//--- * @param {string} [opts.name]
//--- * @param {string} [opts.id]
//--- * @param {boolean} [opts.saveState=true]
//--- * @param {boolean} [opts.reloadOnResume=true]
 */
function openFolder(_path, opts = {}) {
  
//---
  let flag = false;
  
  for (let folder of addedFolder) {
    if (folder.url === _path) {
      flag = true;
      break;
    }
  }
    
    
  if (flag) return;
  //---
  let saveState = true;
  let reloadOnResume = true;
  //---
  if ('saveState' in opts) saveState = opts.saveState;
  if ('reloadOnResume' in opts) reloadOnResume = opts.reloadOnResume;
  //---
  
  //const listState = JSON.parse(localStorage.state || '{}');
  const listState = {};
  
  const title = opts.name || getTitle();
  
  const $closeBtn = tag('span', {
  className: 'icon cancel',
  attr: {
  action: 'close'
  },
      onclick:remove
    });
  
  //alert(!!!listState[_path])
  
  let $root = collapsableList(title, !!!listState[_path], "folder", {
    tail: $closeBtn,
    allCaps: true,
    ontoggle: function (state) {
      if (state === "uncollapsed")
        for (let folder of addedFolder)
          if (folder.url !== _path) folder.$node.collapse();

      expandList.call(this);
    }
  });
  
  /**
   * @type {{url: string, $el: HTMLElement, action: "cut"|"copy"}}
   */
  let clipBoard = null;
  const loading = {
    start() {
      $root.$title.classList.add('loading');
    },
    stop() {
      $root.$title.classList.remove('loading');
    }
  };


  const $text = $root.$title.querySelector(":scope>span.text");
  if ($text) {
    $text.style.overflow = "hidden";
    $text.style.whiteSpace = "nowrap";
    $text.style.textOverflow = "ellipsis";
  }
  $root.$title.setAttribute('type', 'root');
  $root.$title.setAttribute('url', _path);
  $root.$title.setAttribute('name', title);

  $root.$ul.onclick =
    $root.$ul.oncontextmenu =
    $root.$title.onclick =
    $root.$title.oncontextmenu = handleItems;

  addedFolder.push({
    url: _path,
    remove,
    $node: $root,
    reload: () => {
      if (!reloadOnResume) return;
      $root.collapse();
      $root.uncollapse();
    },
    reloadOnResume,
    saveState,
    title,
    id: opts.id
  });
//alert(JSON.stringify(_path));
//alert(JSON.stringify(opts));

  updateHeight();
  recents.addFolder(_path, opts);

  function getTitle() {
  let title = '';
  try {
        const {
          username,
          hostname,
          port
        } = new URL(_path);
        if (username && hostname) title = `${username}@${hostname}`;
        else if (hostname) title = hostname;
  
        if (hostname && port) title += ':' + port;
  
        if (title) return title;
        else return path.basename(_path);
  
      } catch (error) {
        return path.basename(_path);
      }
  }

  function remove(e) {

    if (e) {
      e.preventDefault();
      e.stopPropagation();
      e.stopImmediatePropagation();
    }

    if ('recentFolders' in localStorage) {
      const files = JSON.parse(localStorage.getItem('recentFolders'));

      var new_folder = files.filter(filee => {

          if(!(filee.opts.name.toUpperCase().includes($root.$title.text))){
            return filee;
          }
          
        });
     localStorage.recentFolders = JSON.stringify(new_folder);
      
    }


    if ($root.parentElement) {
      $root.remove();
      $root = null;
    }
    const tmpFolders = [];
    for (let folder of addedFolder)
      if (folder.url !== _path) tmpFolders.push(folder);
    addedFolder = tmpFolders;
    updateHeight();
  }

  function updateHeight() {

    openFolder.updateHeight();

  }



  /**
  //---   * 
  //---   * @param {Event} e 
  */
  function handleItems(e) {
    const mode = e.type;
    const $target = e.target;
    if (!($target instanceof HTMLElement)) return;
    const type = $target.getAttribute('type');
    if (!type) return;
    const url = $target.getAttribute('url');
    const name = $target.getAttribute('name');

    if (mode === 'click') handleClick(type, url, name, $target);
    else if (mode === 'contextmenu') handleContextmenu(type, url, name, $target);
  }



  function handleClick(type, uri, name, $target) {
    if (type === 'file') {

      const options = {
        name,
        uri
      };
      openFile(options);
      editorManager.sidebar.hide();

    }
  }
  
function handleContextmenu(type, url, name, $target) {
    
    const cancel = strings.cancel + (clipBoard ? ' (' + clipBoard.action + ')' : '');
  
    const COPY = ['copy', strings.copy, 'copy'],
      CUT = ['cut', strings.cut, 'cut'],
      REMOVE = ['delete', strings.delete, 'delete'],
      RENAME = ['rename', strings.rename, 'edit'],
      PASTE = ['paste', strings.paste, 'paste', !!clipBoard],
      NEW_FILE = ['new file', 'new file', 'document-add'],
      NEW_FOLDER = ['new folder', 'new folder', 'folder-add'],
      CANCEL = ['cancel', cancel, 'clearclose'],
      OPEN_FOLDER = ['open-folder', 'open folder', 'folder'];

    let options;

    if (type === 'file') options = [COPY, CUT, RENAME, REMOVE];
    else if (type === 'dir') options = [COPY, CUT, REMOVE, RENAME, PASTE, NEW_FILE, NEW_FOLDER, OPEN_FOLDER];
    else if (type === 'root') options = [RENAME, PASTE, NEW_FILE, NEW_FOLDER];

    if (clipBoard) options.push(CANCEL);
   // alert(JSON.stringify(type));
    
  
  //  alert(name)
   // alert(JSON.stringify(options));
    dialogs.select(name, options).then(res => {

        execOperation(type, res, url, $target, name)
          .finally(loading.stop);
      });
    

  }


  function execOperation(type, action, url, $target, name) {
   
   let newName, CASE = '',
      src, srcName, srcType, $src, file, msg, defaultValue;

    if (type === "dir") {
      Url.join(url, "/");
    }

    const target = $target.getAttribute('state');

    switch (action) {
      case "copy":
      case "cut":
        clipBoard = {
          url,
          action,
          $el: $target
        };

        if (action === "cut") $target.classList.add('cut');
        else $target.classList.remove('cut');
        
        return Promise.resolve();

      case "delete":
        msg = "delete {name}".replace('{name}', name);

        return dialogs.confirm(strings.warging, msg)
          .then(res => {
            loading.start();

            return fsOperation(url);
          })
          .then(fs => {
            if (type === "dir") return fs.deleteDir();
            else if (type === "file") return fs.deleteFile();
          })
          .then(res => {
            if (type === 'file') $target.remove();
            else $target.parentElement.remove();

            helpers.showToast(strings.success);
          })
          .catch(err => {
            helpers.error(err);
            console.error(err);
          });


      case "rename":

        return dialogs.prompt(strings.rename, name, "text", {
            match: constants.FILE_NAME_REGEX,
            required: true
          })
          .then(newname => {
            loading.start();
            newName = newname;
            if (newName !== name)
              return fsOperation(url)
                .then(fs => {
                  return fs.renameTo(newName);
                })
                .then(newURL => {

                  const protocol = Url.getProtocol(newURL);

                  $target.querySelector(':scope>.text').textContent = newName;
                  $target.setAttribute('url', newURL);
                  $target.setAttribute('name', newName);

                  if (type === 'file') {
                    $target.querySelector(':scope>span').className = helpers.getIconForFile(newName);
                    let file = editorManager.getFile(url, "uri");
                    if (file) {
                      file.uri = newURL;
                      file.filename = newName;
                    }
                  } else {
                    //Reloading the folder by collasping and expanding the folder
                    $target.click(); //collaspe
                    $target.click(); //expand
                  }

                  helpers.showToast(strings.success);
                });
          })
          .catch(err => {
            helpers.error(err);
            console.error(err);
          });

      case "paste":
        $src = clipBoard.$el;
        srcType = $src.getAttribute('type');

        src = $src.isConnected ?
          (srcType === "file" ? $src.parentElement : $src.parentElement.parentElement)
          .previousElementSibling.getAttribute('state') :
          "uncollapsed";
        srcName = $src.getAttribute('name');

        CASE += srcType === "file" ? 1 : 0;
        CASE += src === "collapsed" ? 1 : 0;
        CASE += target === "collapsed" ? 1 : 0;

        return fsOperation(clipBoard.url)
          .then(fs => {
            //alert(clipBoard.url)
        //    alert(url)
        //    alert(358)
            if (clipBoard.action === 'cut') return fs.moveTo(url);
            else return fs.copyTo(url);
          })
          .then(newUrl => {

            /**
             * CASES:
             * CASE 111: src is file and parent is collapsed where target is also collapsed
             * CASE 110: src is file and parent is collapsed where target is uncollapsed
             * CASE 101: src is file and parent is uncollapsed where target is collapsed
             * CASE 100: src is file and parent is uncollapsed where target is also uncollapsed
             * CASE 011: src is directory and parent is collapsed where target is also collapsed
             * CASE 001: src is directory and parent is uncollapsed where target is also collapsed
             * CASE 010: src is directory and parent is collapsed where target is also uncollapsed
             * CASE 000: src is directory and parent is uncollapsed where target is also uncollapsed
             */

            if (clipBoard.action === 'cut') { //move

              // const newUrl = Url.join(url, srcName);

              switch (CASE) {
                case '111':
                case '011':
                  break;

                case '110':
                  appendTile($target, createFileTile(srcName, newUrl));
                  break;

                case '101':
                  $src.remove();
                  break;

                case '100':
                  appendTile($target, createFileTile(srcName, newUrl));
                  $src.remove();
                  break;

                case '001':
                  $src.parentElement.remove();
                  break;

                case '010':
                  appendList($target, createFolderTile(srcName, newUrl));
                  break;

                case '000':
                  appendList($target, createFolderTile(srcName, newUrl));
                  $src.parentElement.remove();
                  break;

                default:
                  break;
              }

            } else { //copy

              switch (CASE) {
                case '111':
                case '101':
                case '011':
                case '001':
                  break;

                case '110':
                case '100':
                  appendTile($target, createFileTile(srcName, newUrl));
                  break;

                case '010':
                case '000':
                  appendList($target, createFolderTile(srcName, newUrl));
                  break;

                default:
                  break;
              }

            }

            helpers.showToast(strings.success);
            clipBoard = null;

          })
          .catch(err => {
            helpers.error(err);
            console.error(err);
          });

      case "new file":
        
      case "new folder":
        msg = action === "new file" ? "enter file name" : "enter folder name";
        defaultValue = action === "new file" ? constants.DEFAULT_FILE_NAME : 'new folder';
        return dialogs.prompt(msg, defaultValue, "text", {
            match: constants.FILE_NAME_REGEX,
            required: true
          })
          .then(res => {
            loading.start();
            newName = res;
            return fsOperation(url);
          })
          .then(fs => {
            if (action === "new file") return fs.createFile(newName);
            else return fs.createDirectory(newName);
          })
          .then(newUrl => {
            newName = Url.basename(newUrl);
            if (target === "uncollapsed") {
              if (action === "new file") appendTile($target, createFileTile(newName, newUrl));
              else appendList($target, createFolderTile(newName, newUrl));
            }

            helpers.showToast(strings.success);
          })
          .catch(err => {
            helpers.error(err);
            console.error(err);
          });

      case "cancel":
        clipBoard.$el.classList.remove('cut');
        clipBoard = null;
        return Promise.resolve();

      case "open-folder":
        const obj = JSON.parse(JSON.stringify(opts));
        obj.name = name;
        openFolder(url, obj);
        return Promise.resolve();

    }

    /**
     * 
     * @param {HTMLElement} $target 
     * @param {HTMLElement} $src 
     */
    function appendTile($target, $src) {
      $target = $target.nextElementSibling;
      const $firstTile = $target.querySelector(':scope>[type=file]');
      if ($firstTile) $target.insertBefore($src, $firstTile);
      else $target.append($src);

    }

    /**
     * 
     * @param {HTMLElement} $target 
     * @param {HTMLElement} $src 
     */
    function appendList($target, $src) {
      $target = $target.nextElementSibling;
      const $firstList = $target.firstElementChild;
      if ($firstList) $target.insertBefore($src, $firstList);
      else $target.append($src);
    }


}

  function createFileTile(name, url) {
  // alert(helpers.getIconForFile(name));
    const $tile = tile({
      lead: tag('span', {
        className: helpers.getIconForFile(name)
      }),
      text: name
    });
    $tile.setAttribute('url', url);
    $tile.setAttribute('name', name);
    $tile.setAttribute('type', 'file');

    return $tile;
  }
  
  function createFolderTile(name, url) {

    const $list = collapsableList(name, !!!listState[url], "folder", {
      ontoggle: expandList
    });
    $list.$title.setAttribute('url', url);
    $list.$title.setAttribute('type', 'dir');
    $list.$title.setAttribute('name', name);

    return $list;
  }
  

   
  function expandList() {
    const $target = this.$title;
    const $ul = this.$ul;
    const url = $target.getAttribute("url");
    const state = $target.getAttribute("state");

    if (!$ul) return;
    $ul.textContent = null;

    if (saveState) listState[url] = false;

    if (state === 'uncollapsed') {
      loading.start();
      if (saveState) listState[url] = true;
      fsOperation(url)
        .then(fs => {
          return fs.lsDir();
        })
        .then(entries => {
          entries = helpers.sortDir(entries, {
            sortByName: true,
            showHiddenFiles: true
          }, true);
          entries.map(entry => {
            const name = entry.name || path.basename(entry.url);
            if (entry.isDirectory) {

              const $list = createFolderTile(name, entry.url);
              $ul.appendChild($list);

            } else {

              const $item = createFileTile(name, entry.url);
              $ul.append($item);

            }
          });
        })
        .catch(err => {
         // this.collapse();
       //   helpers.error(err);
         // console.error(err);
        })
        .finally(() => {
          loading.stop();
        });
    }

    // localStorage.setItem('state', JSON.stringify(listState));
  }
  
  
}

openFolder.updateHeight = function () {
  if (!addedFolder.length) return;
  let activeFileListHeight = 0;

  let totalFolder = addedFolder.length - 1;

 
  for (let folder of addedFolder) {
    folder.$node.style.maxHeight = `calc(100% - ${totalFolder*30}px)`;
    folder.$node.style.height = `calc(100% -  ${totalFolder*30}px)`;
  } 
};


/*
//---openFolder.updateItem = function (oldFile, newFile, newFilename) {
//---  const $el = editorManager.sidebar.querySelector(`[url="${oldFile}"]`);
//---  if ($el) {
//---    $el.setAttribute('url', newFile);
//---    $el.setAttribute('name', newFilename);
//---    $el.querySelector(':scope>span').className = helpers.getIconForFile(newFilename);
//---    $el.querySelector(':scope>.text').textContent = newFilename;
//---  }
//---};
//---
//---openFolder.removeItem = function (url) {
//---  const $el = editorManager.sidebar.querySelector(`[url="${url}"]`);
//---  if ($el) $el.remove();
//---};
*/
export default openFolder;
