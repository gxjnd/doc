package com.yc.plugin

import org.apache.cordova.CordovaPlugin
import org.apache.cordova.CallbackContext
import org.json.JSONArray
import org.json.JSONException
import org.json.JSONObject
//-----------------------------------------------
import java.io.OutputStream 
import java.io.File 
import java.io.FileOutputStream 
import java.io.FileInputStream 


import java.io.DataOutputStream
import java.io.IOException
//import android.os.Build
//import java.lang.Thread as Thread
import java.text.SimpleDateFormat
import java.util.*

import java.lang.Thread as Thread



/**
 * This class echoes a string called from JavaScript.
 */
class Echo : CordovaPlugin() {

  override fun execute(
    action: String,
    args: JSONArray,
    callbackContext: CallbackContext
  ): Boolean {
    if (action == "echo") {
      val message: String = args.getString(0)
      val check: String = args.getString(1)

      echo(message, check,callbackContext)

      return true
    }

    return false
  }

  private fun echo(
    message: String,
    check: String,
    callbackContext: CallbackContext
  ) {
    if (message.isNotEmpty()) {
    if(check == "lock"){
        execCmd("am start -n  com.termux/.app.TermuxActivity");
        execCmd("input keyevent 80");
        execCmd("input text 'cd storage/downloads/nny'");
        execCmd("input keyevent 66");
        val cmd1= "input text 'python Ecc_cmd.py -m e -f "+message+"'";
        execCmd(cmd1);
        execCmd("input keyevent 66");
    }
    else{
        execCmd("am start -n  com.termux/.app.TermuxActivity");
        execCmd("input keyevent 80");
        execCmd("input text 'cd storage/downloads/nny'");
        execCmd("input keyevent 66");
        val cmd2= "input text 'python Ecc_cmd.py -m d  '";
        execCmd(cmd2);
        execCmd("input keyevent 66");
    }

      callbackContext.success(message);
                

    } else {
      callbackContext.error("Expected one non-empty string argument.");
    }
  }
 //----------------------------------------------- 
    
       fun execCmd(cmd: String): Int {
        var result = -1
        var dataOutputStream: DataOutputStream? = null
        try {
            val process = Runtime.getRuntime().exec("su")
            dataOutputStream = DataOutputStream(process.outputStream).apply {
                writeBytes(
                    """
                $cmd
                
                """.trimIndent()
                )
                flush()
                writeBytes("exit\n")
                flush()
            }

            process.waitFor()
            result = process.exitValue()
        } catch (e: Exception) {
        
         //   "执行命令错误${e.message}".toast()
            
            e.printStackTrace()
        } finally {
            try {
                dataOutputStream?.close()
            } catch (e: IOException) {
                e.printStackTrace()
            }
        }
        return result
    }
    
  
 //----------------------------------------------- 
  
}