import tag from 'html-tag-js';
import tile from './tile';
import Dictionary from "./dictionary";
import Link from "./link";
import Note from "./note";
import mustache from 'mustache';
import $_wb_list from '../views/deal_wb_li.hbs';



function Website() {
  //alert(1)
      const leadBtn =  tag('span', {
        className: 'icon arrow_back',
        onclick: ()=>{
          setTimeout(() => {
            $page.remove();
        }, 150);
        },
        attr: {
            action: 'go-back'
        }
    });
      const header = tile({

        type: 'header',

        text: "website",
        lead: leadBtn,
        tail: undefined
    });
    
    const $page = tag('div', {
        className: 'w_website',
        child: header
    });
    const $main = tag('div', {
        className: 'wb_main'
    });

  $page.append($main);

  var wb_li=[
    {"pic":"../../dict.png","name":"dictionary"},
    {"pic":"../../link.png","name":"link"},
    {"pic":"../../note.png","name":"note"}
    ];
    const $mustache_list = tag.parse(mustache.render($_wb_list, {wb_li}));
    $main.append($mustache_list);


  
  
  document.body.append($page);
  deal_list()
  function deal_list(){

   var ul = document.getElementById('w_list_id');


  ul.onclick = async function(event) {
      var target = event.target;
     // console.log(target)
      var li = target.closest('li');
      //console.log(li)
      var nodes = Array.from( li.closest('ul').children );
      var index = nodes.indexOf( li );
      const name =wb_li[index]["name"]
      if(name=="dictionary"){
          Dictionary()
      }
      else if(name=="link"){
          Link()
      }
      else if(name=="note"){
     //   alert(name)
          Note()
      }
      else{
      return;
      }


 	  
                                                                                                                                                                               
  
  };


 }
  
  

}

export default Website;