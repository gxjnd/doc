import tag from 'html-tag-js';
import tile from './tile';
import fsOperation from "../src/fileSystem/fsOperation";

import helpers from "../src/utils/helpers";
import dialogs from './dialogs';
import constants from '../src/constants';

//import mustache from 'mustache';


async function Gallery() {
  //alert(1)
  var cursor_list=[];
      const leadBtn =  tag('span', {
        className: 'icon arrow_back',
        onclick: ()=>{
          setTimeout(() => {
            $page.remove();
        }, 150);
        },
        attr: {
            action: 'go-back'
        }
    });
      const header = tile({

        type: 'header',

        text: "website",
        lead: leadBtn,
        tail: undefined
    });
    
    const $page = tag('div', {
        className: 'jan_gallery',
        child: header
    });



    const $main = tag('div', {

        className: 'g_main'

    });
    
    var $ul_main = tag('ul', {

        className: 'gallery_list',
        id: 'gallery_list_id'

    });
    var $tail_3 =  tag('div', {
      className: 'tail_3',
      attr: {
          action: 'back'
      },
      innerHTML:'+'
    });
    var $tail_4 =  tag('div', {
      className: 'tail_4',
      attr: {
          action: 'back'
      }
    //  innerHTML:'+'
    });
    var $tail_2 =  tag('div', {
      className: 'tail_2',
      attr: {
          action: 'back'
      }
    //  innerHTML:'+'
    });

  //  <ul class="w_list" id="w_list_id"   >

      const $path_p=cordova.file.externalRootDirectory+"Download/t.png";
      
    const $test_p = tag('img', {

        className: 'test_poc',
        id: 'test_p50',
        src: $path_p

    });

  $page.append($main);
  document.body.append($page);
  $main.append($ul_main)
//  header.insertBefore($tail_2, header.lastChild);
  header.insertBefore($tail_3, header.lastChild);
  header.insertBefore($tail_4, header.lastChild);

function deleteAllProperties(obj) {
    for (var key in obj) {
        if (obj.hasOwnProperty(key)) {
            delete obj[key];
        }
    }
}

  function loadImageFromFile(filename,element) {
        window.resolveLocalFileSystemURL(filename, function success(fileEntry) {
            fileEntry.file(function (file) {
                var reader = new FileReader();
                reader.onloadend = function() {
                    if (this.result) {
                        var elem = element
                        //document.getElementById("test_p50");
                        var blob = new Blob([new Uint8Array(this.result)], { type: "image/png" });

                        elem.src = window.URL.createObjectURL(blob);

                      
                    }
                    else{
                  //    alert(766)
                      //father.remove()
                  //    return false
                    }
                };
                reader.readAsArrayBuffer(file);
            });
        }, function () {
            alert("File not found: ");
        });
    }
  function add_li(name){
    
        var $li_item = tag('li', {
        className: 'gallery_li'
       
        
    });
        var $div_g = tag('div', {
        className: 'gallery_div'

        
    });
        var $item = tag('div', {
        className: 'item_text'
        
        
    });
        var $item_s = tag('div', {
        className: 'item_text_s',
        innerHTML:name
        
    });
    
        $li_item.append($item)
        $item.append($item_s)
        $ul_main.append($li_item,$div_g)

  
  
  
  
  }
  
  const $path_g=cordova.file.externalRootDirectory+"Download/nny/gallery.json";
  const fs = await fsOperation($path_g);
//alert(98)
  const binData = await fs.readFile();
  let text = helpers.decodeText(binData);
  var link_a=JSON.parse(text)
  
  for(var index=0;index<link_a.length;index++) {
    
    add_li(link_a[index][0]);
  }
  /*
  const $path_img=cordova.file.externalRootDirectory+"Download/nny/gallery_img.json";
  const fs_img = await fsOperation($path_img);
  const binData_i = await fs_img.readFile();

  let text_i = helpers.decodeText(binData_i);
*/
//  var img_a=JSON.parse(text_i)
  
  
 // add_li("chemical")
 // add_li("electric")
 // add_li("others")
 // add_li("euruu")
  var save_click=0;
  $ul_main.onclick = async function(event) {

      var target = event.target;

     // console.log(target)
      var li = target.closest('li');
      var $li_next = target.closest('li').nextSibling;
   //   var $pic_div = target.closest('div_288');
    
 //     var nodes = Array.from( li.closest('ul').children );
  //    var index = nodes.indexOf( li );
//      var c_name =link_a[index][0]
 //     alert(c_name)
//      alert(index)
      var get_n=li.childNodes[0].childNodes[0].innerHTML
      for(var x = 0; x < link_a.length; x++) {
      if(link_a[x][0]==get_n){
        save_click=x;
        if(link_a[x][1]==''){
        var $div_empty = tag('div', {
        className: 'empty',
        innerHTML: '[add picture]'
        });
        if($li_next.childNodes.length==0){
        $li_next.append($div_empty)
        $div_empty.onclick = async function(){
        $main.innerHTML='';
     //   while ($main.firstChild) {
    //$main.firstChild.remove()
      //}
   //     $main.replaceChildren();
      //for(i=0; i<$main.childNodes.length; i++){
      //$main.childNodes[i].remove()
      //}
        var $main_2 = tag('div', {



        className: 'main_2'

        });
        $main.append($main_2);
        
        $main_2.onclick = async function(event){

  var target = event.target;

  if (target.matches('.div_select_204')) {
  //    alert(566)
      if(cursor_list.length==0){
      var selector = [target.getAttribute("pic_url"),target.getAttribute("pic_name")]
      cursor_list.push(selector)
      //alert(selector);
      target.innerHTML="s";
      target.style.backgroundColor="#fff";
      }else{
        var new_pic=target.getAttribute("pic_url")
        var selector_2 = [target.getAttribute("pic_url"),target.getAttribute("pic_name")]
        var exist=false
        var local=0
        for(var i=0;i<cursor_list.length;i++){
          if(cursor_list[i][0]==new_pic){
            local=i;
            exist=true;
            break;
          }
        }
        if(exist){
          cursor_list.splice(local, 1);
          target.innerHTML="";
          target.style.backgroundColor="rgba(0, 0, 0, 0)";
        }else{
          cursor_list.push(selector_2)
          target.innerHTML="s";
          target.style.backgroundColor="#fff";
        }
        
      }
      
      return
    }
  
     // console.log(target)
      var img = target.closest('.div_204');
      img.style.width="100%";
      img.style.height="auto";
      img.style.borderBottom="11px solid black";
      img.style.borderTop="11px solid black";
      

    var dist1=0;
    function start(ev) {
           if (ev.targetTouches.length == 2) {//check if two fingers touched screen
               dist1 = Math.hypot( //get rough estimate of distance between two fingers
                ev.touches[0].pageX - ev.touches[1].pageX,
                ev.touches[0].pageY - ev.touches[1].pageY);                  
           }
    
    }
    function move(ev) {
           if (ev.targetTouches.length == 2 && ev.changedTouches.length == 2) {
                 // Check if the two target touches are the same ones that started
               var dist2 = Math.hypot(//get rough estimate of new distance between fingers
                ev.touches[0].pageX - ev.touches[1].pageX,
                ev.touches[0].pageY - ev.touches[1].pageY);
                //alert(dist);
                if(dist1>dist2) {//if fingers are closer now than when they first touched screen, they are pinching
                 // alert('zoom out');
                    img.style.width="calc((100vw )*0.333)";
                    img.style.height="calc((100vw )*0.333)";
                    img.style.backgroundColor="rgba(45, 85, 255, 1)";
                    setTimeout(()=>{
                      img.style.backgroundColor="#F0F7E0";

                            img.style.border="1px solid white";


                    },500);
                    img.removeEventListener ('touchstart', start, false);
                    img.removeEventListener('touchmove', move, false);


                }
                if(dist1<dist2) {//if fingers are further apart than when they first touched the screen, they are making the zoomin gesture
              //     alert('zoom in');
                }
           }
           
    }
        img.addEventListener ('touchstart', start, false);
        img.addEventListener('touchmove', move, false);

  }

      //  var gallery_dir=["Download","DCIM/Camera","DCIM/Screenshots","Pictures","android/media/com.app.camerarectsample/Zapture"]
        var gallery_dir=["Download"]
        function get_pic(url){
        fsOperation(url)      
        .then(fs => {
          return fs.lsDir();
        })
        .then(entries => {
            entries = helpers.sortDir(entries, {
            sortByName: true,
            showHiddenFiles: true
          }, true);
        //  alert(JSON.stringify(entries))
                    entries.map(entry => {
            const name = entry.name || path.basename(entry.url);
            if (entry.isDirectory) {
          //    const $list = createFolderTile(name, entry.url);
          //    $ul.appendChild($list);
            } else {
           // alert(name)
                  if (name.includes("jpg") ||name.includes("png") ||name.includes("jpeg")  ){
                    var $div_204 = tag('div', {
                      className:"div_204"
                  });
                    var $div_select_204 = tag('div', {
                      className:"div_select_204",
                      attr: {
                        pic_url: entry.url,
                        pic_name:name
                    //    random:getRandomInt(0,999999)
                      }
                  });
                    var $img_195 = tag('img', {
                      className:"img_all",
                      attr: {
                        pic_url: entry.url,
                        pic_name:name
                      },
                      alt:entry.url
                  });
                   // $div_select_204.innerHTML="";
                   // $div_select_204.style.backgroundColor="rgba(0, 0, 0, 0)";


                  $main_2.append($div_204)
                  $div_204.append($div_select_204,$img_195)
                  loadImageFromFile(entry.url,$img_195)
                  }
   // $li_next.append($div_158)
           //   const $item = createFileTile(name, entry.url);
        //      $ul.append($item);
            }
          });
        })
        .catch(err => {
       //   alert("err");
        })
        
        
      }
        for (var j=0;j<gallery_dir.length;j++){
         var url= cordova.file.externalRootDirectory+gallery_dir[j];
       //  alert(url)
          get_pic(url);
        }
      }
    //  alert(get_n)
      
    }else{
      $li_next.innerHTML= '';
      
    }
 //     return;
      }
        else{
          //272      
          
          if($li_next.childNodes.length==0){
           // link_a[x][1][2]
          // alert(link_a[x][1][0][1][0])
       //    alert(link_a[x][1][0][1].length)
           var $div_286 = tag('div', {
                  className:"div_286"
              });
            var $div_289 = tag('div', {
                  className:"div_289",
                  innerHTML:link_a[x][1][0][1][0]
              });
              $div_286.append($div_289);
              
          for(var j=0;j<link_a[x][1][0][2].length;j++){

            var $div_288 = tag('div', {
                  className:"div_288"
              });
            var $img_273 = tag('img', {

                  className:"img_273",

                  attr: {
                    pic_url: link_a[x][1][0],
                    pic_name:link_a[x][1][0]
                  },
                  alt:link_a[x][1][0][2][j][1]
              });
              
              loadImageFromFile(link_a[x][1][0][2][j][0],$img_273)
              if(link_a[x][1][0][2][j].length==2){
                var layout={}
                
                layout["d_width"]="100%"
                layout["d_height"]="500px"
                layout["i_width"]="100%"
                layout["i_height"]="auto"
                layout["i_margin"]="0 auto auto 0"
                link_a[x][1][0][2][j].push(layout)
            //    alert(JSON.stringify(link_a[x][1][0][2][j]))
                //alert(JSON.stringify(link_a[x][1][0][2][j]))
                $div_288.style.width=link_a[x][1][0][2][j][2].d_width;
                $div_288.style.height=link_a[x][1][0][2][j][2].d_height;
                $img_273.style.width=link_a[x][1][0][2][j][2].i_width;
                $img_273.style.height=link_a[x][1][0][2][j][2].i_height;
                $img_273.style.margin=link_a[x][1][0][2][j][2].i_margin;
                var data_319= JSON.stringify(link_a, null, '\t');
               
               // alert(layout)
                await fs.writeFile(data_319);
            }else{
              const binData_334 = await fs.readFile();
              let text_335 = helpers.decodeText(binData_334);
              var link_a_336=JSON.parse(text_335)
              $div_288.style.width=link_a_336[x][1][0][2][j][2].d_width;
              $div_288.style.height=link_a_336[x][1][0][2][j][2].d_height;
              $img_273.style.width=link_a_336[x][1][0][2][j][2].i_width;
              $img_273.style.height=link_a_336[x][1][0][2][j][2].i_height;
              $img_273.style.margin=link_a_336[x][1][0][2][j][2].i_margin;
            }
              $div_288.append($img_273)
              $div_286.append($div_288);
          }
            
        $li_next.append($div_286)
          }else{
          //  alert("emp")
            $li_next.innerHTML="";
        //    $li_next.replaceChildren();
          }
              
        }
      break;
      }
        
      }
   //   if($pic_div){
        
    //  }
//  loadImageFromFile($path_p)

  }
  function getRandomInt(min, max) {
    min = Math.ceil(min);
    max = Math.floor(max);
    return Math.floor(Math.random() * (max - min) + min); // The maximum is exclusive and the minimum is inclusive
  }
  
  $tail_3.onclick = async function(){
  dialogs.prompt("rename", "", "text", {
            match: constants.FILE_NAME_REGEX,
            required: true
          })
          .then(async newname => {
           // alert(link_a)
            var new_g= [newname,[]]
            link_a.push(new_g);
            var data= JSON.stringify(link_a, null, '\t');
            await fs.writeFile(data);
            add_li(newname)
      //  add_link(new_link);
          //  link_a.push(new_link);
          })
          .catch(err => {
           // helpers.error(err);
            alert("err");
          });
    
  }
  $tail_4.onclick = async function(){
    if(cursor_list.length==0){
      return;
    }
    $main.innerHTML='';
 //$main.replaceChildren();
   // alert("send")
    dialogs.prompt("name", "", "text", {
            match: /(.*?)/g,
            required: true
          })
          .then(async newname => {
           // alert(link_a)
          
           var id_324 = Date.now().toString()+getRandomInt(0,999)


            var new_img= [[id_324],[newname],cursor_list]
            link_a[save_click][1]=[new_img];
            var data_331= JSON.stringify(link_a, null, '\t');
            await fs.writeFile(data_331);
            $main.append($ul_main)
           $ul_main.innerHTML="";
         // $ul_main.replaceChildren();
            for(var index=0;index<link_a.length;index++) {
              add_li(link_a[index][0]);
            }
            cursor_list=[]
      //      var selector_del= document.querySelectorAll(".div_select_204")
//  alert(selector_del.length)
 //   for (var i=0;i<selector_del.length;i++){
 //     selector_del[i].remove()
//    }
           // add_li(newname)
      //  add_link(new_link);
          //  link_a.push(new_link);
          })
          .catch(err => {
           // helpers.error(err);
            alert("err");
          });
  }
  $tail_2.onclick = async function(){
    
    
  }
  
}

export default Gallery;