import tag from 'html-tag-js';
/**
 * 
 * @param {string} titleText 
 * @param {string} message 
 * @returns {Promise<void>}
 */
function confirm(titleText, message) {
  return new Promise((resolve, reject) => {
    if (!message && titleText) {
      message = titleText;
      titleText = '';
    }

    const titleSpan = tag('strong', {
      className: 'title',
      textContent: titleText
    });
    const messageSpan = tag('span', {
      className: 'message scroll',
      textContent: message
    });
    const okBtn = tag('button', {
      textContent: "ok",
      onclick: function () {
        hide();
        resolve();
      }
    });
    const cancelBtn = tag('button', {
      textContent: "cancel",
      onclick: function () {
        hide();
        reject(false);
      }
    });
    const confirmDiv = tag('div', {
      className: 'prompt confirm',
      children: [
        titleSpan,
        messageSpan,
        tag('div', {
          className: 'button-container',
          children: [
            cancelBtn,
            okBtn
          ]
        })
      ]
    });
    const mask = tag('span', {
      className: 'mask'
    });

    side_push({
      id: 'confirm',
      action: hideAlert
    });

    app.append(confirmDiv, mask);
   // window.restoreTheme(true);

    function hideAlert() {
      confirmDiv.classList.add('hide');
    //  window.restoreTheme();
      setTimeout(() => {
        app.removeChild(confirmDiv);
        app.removeChild(mask);
      }, 300);
    }

    function hide() {
      side_remove('confirm');
      hideAlert();
    }
  });
}
const stack = [];
 function side_push(fun) {
      stack.push(fun);
  }

    

function side_remove(id) {
    for (let i = 0; i < stack.length; ++i) {
        let action = stack[i];
        if (action.id === id) {
            stack.splice(i, 1);
            return true;
        }
    }

    return false;
}

export default confirm;