import tag from 'html-tag-js';
import tile from './tile';
import fsOperation from "../src/fileSystem/fsOperation";
import helpers from "../src/utils/helpers";
import mustache from 'mustache';
import $_dict from '../views/dict_list.hbs';

async function Dictionary() {
  //alert(1)
      const leadBtn =  tag('span', {

        className: 'icon arrow_back',

        onclick: ()=>{
          setTimeout(() => {

            $page.remove();

        }, 150);
        },
        attr: {
            action: 'go-back'
        }
    });
      const header = tile({

        type: 'header',

        text: "website",
        lead: leadBtn,
        tail: undefined
    });
    
    const $page = tag('div', {
        className: 'w_website',
        child: header
    });
    const $main = tag('div', {
        className: 'dict_main'
    });
    const $content_top = tag('div', {

        className: 'dict_content_top'

    });
    const $content_top_s = tag('div', {
        className: 'dict_content_top_s'

    });
    const $search = tag('input', {
        type: 'text',
        className: 'dict_search'
    });
    const $rm_54 = tag('div', {
        className: 'icon cancel'
    });
    
    
    const $content = tag('div', {
        className: 'dict_content'
    });
    const $dict_form = tag('div', {
        className: 'dict_form'
       // action: '',
     //   method: 'POST'
    });

      const $dict_key = tag('input', {
        type: 'text',
        className: 'dict_key'

    });
    

    
    const $dict_colon = tag('div', {

        innerHTML: ':'

    });
      const $dict_value = tag('input', {
        type: 'text',
        className: 'dict_value'

    });
    
      const $dict_submit = tag('button', {
        type: 'submit',
        className: 'dict_submit',
        innerHTML: 'Submit',
        onclick:deal_submit

    });
    
    const $content_bottom = tag('div', {

        className: 'dict_content_bottom'

    });
    const $content_bottom_a = tag('div', {

        className: 'dict_content_bottom_a'

    });
    const $content_bottom_b = tag('div', {

        className: 'dict_content_bottom_b'

    });

  $page.append($main);
  $main.append($content_top,$content,$content_bottom);
  $content.append($dict_form);

  $dict_form.append($dict_key,$dict_colon,$dict_value,$dict_submit);             
  
  document.body.append($page);
  const $keyValue = document.querySelector('.dict_key');
  const $valueValue = document.querySelector('.dict_value');
  
  const $path_f=cordova.file.externalRootDirectory+"Download/nny/eng.json";
  const fs = await fsOperation($path_f);
  const binData = await fs.readFile();
  let text = helpers.decodeText(binData);
  var json_eng=JSON.parse(text)
  var hbs_list=get_li(json_eng)
  
  
  const $mustache_list = tag.parse(mustache.render($_dict, {hbs_list}));
  //alert(mustache.render($_dict, {hbs_list}))
  $content_top.append($content_top_s,$mustache_list);
  $content_top_s.append($search,$rm_54)
  const $searchValue = document.querySelector('.dict_search');


  $content_bottom.append($content_bottom_a,$content_bottom_b)
  
  deal_list();
  loopcb();
  function loopcb(){
    get_clipboard();
  
  setTimeout(loopcb,1000);
  }
  
  async function deal_submit(){
  //alert(1);
  //alert(JSON.stringify($valueValue.value));
  //alert($keyValue.value);
  const kv=$keyValue.value.trim();
  
  const vv=$valueValue.value.trim();
  //  alert(typeof(kv))
  //  alert(vv)
  if(kv&&vv){
  if(isChinese(kv[0])){
  return;
  }
  for(var i=0; i<json_eng.length; i++) {
    for (const [key, value] of Object.entries(json_eng[i])) {
        if(key==kv) {
          return;
        }
      } 
  }
  
  var new_dict={};
  //  alert();
  new_dict[kv]=vv;
  //alert(typeof(new_dict));
  //alert(typeof(json_eng));
  json_eng.push(new_dict);
  //.toString();
  //alert(JSON.stringify(json_eng[json_eng.length-2]));
  var data= JSON.stringify(json_eng);
  //alert("7")
  //  alert(data)
  await fs.writeFile(data);
  window.plugins.toast.showShortBottom('file saved');
  
  var hbs_list=get_li(json_eng);
  const $mustache_list = tag.parse(mustache.render($_dict, {hbs_list}));
  $content_top.replaceChild($mustache_list, $content_top.childNodes[1]);
  deal_list()
  // $content_top.append($mustache_list);
  //$keyValue.value='';
  }
  const { clipboard } = cordova.plugins;
  clipboard.copy('');
  $keyValue.value='';
  $valueValue.value='';
  }
 function isChinese(temp){
  var re=/[^\u4e00-\u9fa5]/;
  if(re.test(temp)) return false;
  return true;
  }
 function get_li(json_eng){
  
  var hbs_list=[]
  var len_dict_all= json_eng.length;
//alert(len_dict_all);

for (let index = len_dict_all-1; index > len_dict_all-6; index--) {
//alert(JSON.stringify(json_eng[index]));
for (const [key, value] of Object.entries(json_eng[index])) {
      hbs_list.unshift({"key":key, "value" :value});

}
}
return hbs_list;
  }
 function deal_list(){
   var ul = document.getElementById('d_list_id');

  ul.onclick = async function(event) {
  
    
      var target = event.target;
     // console.log(target)
      var li = target.closest('li');
      //console.log(li)
      var nodes = Array.from( li.closest('ul').children );
    var index = nodes.indexOf( li );
  
   nodes.forEach(function(e) {
        e.classList.remove('removing');
      });
  
  li.classList.add('removing');
  //alert(index)
  if(target.className=="icon cancel"){
  
    var len_engs = json_eng.length
    json_eng.splice(len_engs-(5-index), 1);
    
    var data= JSON.stringify(json_eng);
    await fs.writeFile(data);
  
    window.plugins.toast.showShortBottom('file saved');
  
    var hbs_list=get_li(json_eng);
      const $mustache_list = tag.parse(mustache.render($_dict, {hbs_list}));
    $content_top.replaceChild($mustache_list, $content_top.childNodes[1]);
    deal_list()
  }
  
  
  var cursor_d = json_eng[(json_eng.length)-(5-index)];
  for (const [key, value] of Object.entries(cursor_d)) {
    document.getElementsByClassName("dict_content_bottom_a")[0].innerHTML=key;
  document.getElementsByClassName("dict_content_bottom_b")[0].innerHTML=value;
 
}
 	  
                                                                                                                                                                               
  
  };


 }
 async function get_clipboard (){
//console.log("enter clipboard");
//const data = await navigator.clipboard.read();
const { clipboard } = cordova.plugins;
      clipboard.paste((text) => {
              if(text == ''){
  //  alert("emp");
    setTimeout(get_clipboard,1000);
  }else{
  if(text.length<20){
    if($valueValue==text||$keyValue.value==text){
      return;
    }
            var really_chiness = 0;
          var len_s = text.length
          for (var k = 0 ; k < len_s; k++) {
              if(isChinese(text[k])){
                really_chiness = 1;
                break;
              }
            }
          if(really_chiness) {
            if($valueValue.value==''){
            $valueValue.value=text;
          }
          } else{
            if($keyValue.value==''){
          $keyValue.value=text;
            }
          }
  }
    
  }
  });



}

 

     
  
function get_search_li(results){

  

  var hbs_list=[]
  var len_dict_all= results.length;

for (let index = 0; index < len_dict_all; index++) {
for (const [key, value] of Object.entries(results[index])) {
      hbs_list.push({"key":key, "value" :value});

}
}
return hbs_list;
  }
 

function compareObjects(o1, o2) {
  var k = '';
  for(k in o1) if(o1[k] != o2[k]) return false;
  for(k in o2) if(o1[k] != o2[k]) return false;
  return true;
}

function itemExists(haystack, needle) {
  for(var i=0; i<haystack.length; i++) if(compareObjects(haystack[i], needle)) return true;
  return false;
}
   function find (){
  //no   alert("find")
  var sv = $searchValue.value.trim();
 
 
   var really_chiness = 0;
  var len_s = sv.length
  for (var k = 0 ; k < len_s; k++) {
      if(isChinese(sv[k])){
        really_chiness = 1;
        break;
      }
    }
 
 if((!really_chiness&&sv.length<2)||sv=='')
  {
    return;
  }
  var results = [];
  
  for(var i=0; i<json_eng.length; i++) {
    for (const [key, value] of Object.entries(json_eng[i])) {
        if((key.indexOf(sv)!=-1)||(value.indexOf(sv)!=-1)) {
          if(!itemExists(results, json_eng[i])) results.push(json_eng[i]);
        }
      } 
  }
 // alert(JSON.stringify(results))
 //document.getElementsByClassName("dict_content_bottom_b")[0].innerHTML=JSON.stringify(results);

   var hbs_list=get_search_li(results);

  const $mustache_list = tag.parse(mustache.render($_dict, {hbs_list}));

  $content_top.replaceChild($mustache_list, $content_top.childNodes[1]);

  deal_li_search(results);
  
  }
  function deal_li_search(results){
    
       var ul = document.getElementById('d_list_id');



  ul.onclick = async function(event) {
  
    
      var target = event.target;
     // console.log(target)
      var li = target.closest('li');
      //console.log(li)
      var nodes = Array.from( li.closest('ul').children );
    var index = nodes.indexOf( li );
  
  //alert()
   //const $keyValue = li.querySelector('.key');

  //const $valueValue = li.querySelector('.value');
//var key= $keyValue.value
//var value= $valueValue.value
  
  
  
  
 // var cursor_d = json_eng[(json_eng.length)-(5-index)];
 for (const [key, value] of Object.entries(results[index])) {
    document.getElementsByClassName("dict_content_bottom_a")[0].innerHTML=key;
  document.getElementsByClassName("dict_content_bottom_b")[0].innerHTML=value;
 
}
 	  
                                                                                                                                                                               
  
  };


    
    
  }
  
    $searchValue.oninput = function () {
  //  alert(5)
    if (this.value) find();

  };
  $rm_54.onclick= function(){
    $searchValue.value=''
    
    var hbs_list=get_li(json_eng);
  const $mustache_list = tag.parse(mustache.render($_dict, {hbs_list}));
  $content_top.replaceChild($mustache_list, $content_top.childNodes[1]);
  deal_list()
  }
}
export default Dictionary;