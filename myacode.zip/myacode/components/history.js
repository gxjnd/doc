import tag from 'html-tag-js';



import tile from './tile';
import fsOperation from "../src/fileSystem/fsOperation";
import dialogs from './dialogs';


import helpers from "../src/utils/helpers";

//Input CSS string, Outputs JS Object  

//import mustache from 'mustache';
//import $_wb_list from '../views/deal_wb_li.hbs';



async function History(pattern,db_name) {
  pattern = typeof pattern !== 'undefined' ? pattern : "note";
  db_name = typeof db_name !== 'undefined' ? db_name : "note.db";
  
  //-------------------
  var db=null;
  var insert_23=false;
  var end_24;
  var start_25;
  var s_277=[];
  var s_291=[];
  var init_s152;
  var data_27;
  var show_d=[];
  var long_press=false;
  var insert_pos;
  Element.prototype.appendAfter = function (element) {
  element.parentNode.insertBefore(this, element.nextSibling);
  },false;
 db = window.sqlitePlugin.openDatabase({ name: db_name, location: 'default' }, function (db) {


    // Here, you might create or open the table.
  db.transaction(function (tx) {
    // ...
    tx.executeSql('CREATE TABLE historys (message, time, data,wrap,start,end,id)');
//alert(179)
    
  }, function (error) {
    console.log('transaction error: ' + error.message);
}, function () {
    alert('transaction ok');
});

    // Here, you might create or open the table.

}, function (error) {
    console.log('Open database ERROR: ' + JSON.stringify(error));
});



  //--------------------
  
  
  
  
 // alert(11)
      const leadBtn =  tag('span', {
        className: 'icon arrow_back',
        onclick: ()=>{
          setTimeout(() => {
            $page.remove();
        }, 150);
        },
        attr: {
            action: 'go-back'
        }
    });
      const $leadBtn_c =  tag('div', {
        className: 'cancel_65',
        attr: {
            action: 'back'
        },
        innerHTML:"+"
    });
    

      var $tail_2 =  tag('div', {
        className: 'tail_2',
        attr: {
            action: 'back'
        }
        
    });
      var $tail_3 =  tag('div', {
        className: 'tail_3',
        attr: {
            action: 'back'
        },
        innerHTML:'+'
    });
      var $tail_4 =  tag('div', {
        className: 'tail_4',
        attr: {
            action: 'back'
        }
        
    });
    
      var header = tile({
        type: 'header',
        text: "website",
        lead: leadBtn,
        tail: undefined
    });
    
      var longpress_header = tile({
        type: 'header',
        text: "",
        lead: $leadBtn_c,
        tail: undefined
    });
    
    const $page = tag('div', {
        className: 'n_history',
        child: header
    });
    const $main = tag('div', {
        className: 'n_main'
    });
    const $main_content = tag('div', {

        className: 'n_main_content'

    });

    const $footer = tag('div', {

        className: 'n_footer'

    });
    const $div_message_data = tag('div', {
        className: 'div_message_data'
    });
    const $data_123 = tag('input', {
        className: 'data_123'
    });
    
    const $div_message = tag('div', {
        className: 'div_note_m'
    });
    const $message = tag('textarea', {
        className: 'note_m'
    });
    
    const $send = tag('div', {
        
        className: 'send_m'
    });
    
  $page.append($main,$footer);

  $main.append($main_content);

  $footer.append($div_message_data,$div_message,$send)
  $div_message.append($message)
  
  $div_message_data.append($data_123)
  
  var touch = {
    startX: 0,
    totalX: 0,
    endX: 0,
    startY: 0,
    totalY: 0,
    endY: 0,
    target: null,
  };
  const eventOptions = { passive: false };

   
  
   function ontouchstart(e) {
    const { target } = e;
   // alert(180)
        const { clientX, clientY } = (e.touches ?? [])[0] ?? e;
//alert(181)
 //   if (preventSlideTests.find((test) => test(target))) return;
  //  if (mode === 'tab') return;

   // $el.style.transition = 'none';
    touch.startX = clientX;
    touch.startY = clientY;
    touch.target = target;
  //  alert(190)
/*
    if ($el.activated && !$el.contains(target) && target !== mask) {
   //长按文件夹弹出的对话框
    // alert("target")
      return;
    } else if (
      (!$el.activated && touch.startX > START_THRESHOLD) ||
      target === $toggler
    ) {
     // alert("target")
      return;
    }*/

    $data_123.addEventListener('touchmove', ontouchmove, eventOptions);
    $data_123.addEventListener('touchend', ontouchend, eventOptions);
//alert(204)
  }
     
  function ontouchmove(e) {
    e.preventDefault();

        const { clientX, clientY } = (e.touches ?? [])[0] ?? e;
    touch.endX = clientX;
    touch.endY = clientY;
    touch.totalX = touch.endX - touch.startX;
    touch.totalY = touch.endY - touch.startY;
//alert(1)
//alert( touch.totalX)
if (touch.totalX < 0 ){
  pattern="note"
  init_pattern()
}
 //   let width = $el.getWidth();
//alert(touch.totalX)
   /* if (
      !$el.activated &&
      touch.totalX < width &&
      touch.startX < START_THRESHOLD
    ) {
      if (!$el.isConnected) {
        app.append($el, mask);
        $container.style.overflow = 'hidden';
      }

      $el.style.transform = `translate3d(${-(width - touch.totalX)}px, 0, 0)`;
    } else if (touch.totalX < 0 && $el.activated) {
      $el.style.transform = `translate3d(${touch.totalX}px, 0, 0)`;
    }*/
  }

  /**
   * Event handler for touchend event
   * @param {TouchEvent} e
   */
   
  function ontouchend(e) {
    if (touch.totalX === 0) return resetState();
    e.preventDefault();
    resetState();

  }

  /**
   * Reset the touch state
   */
  function resetState() {
    touch.totalY = 0;
    touch.startY = 0;
    touch.endY = 0;
    touch.totalX = 0;
    touch.startX = 0;
    touch.endX = 0;
    touch.target = null;
  //  $el.style.transition = null;
    $data_123.removeEventListener('touchmove', ontouchmove, eventOptions);
    $data_123.removeEventListener('touchend', ontouchend, eventOptions);
  }
  
 
  function init_pattern(){
  if(pattern=="note"){
      //          s_277[i].style.backgroundColor="rgba(0, 0, 0, 0)";
    //  s_277[i].style.borderBottom="8px solid red";
     // s_277[i].style.borderImage="linear-gradient(to right, transparent 30%, #000 50%) 0 0 100% 0  /0  0 8px 0    ";
//     width: 0; 
//  height: 0; 
 // border-top: 60px solid transparent;
//  border-bottom: 60px solid transparent;
 // border-left: 60px solid green;

 $data_123.style.display="none";
 $div_message_data.style.width="0";
 $div_message_data.style.height="0";
 $div_message_data.style.borderTop="8px solid transparent";
 $div_message_data.style.borderBottom="8px solid transparent";
 $div_message_data.style.borderLeft="8px solid black";
 $div_message_data.style.margin="auto auto 12px 4px";
   //     margin: auto 0px 0px auto;
  $div_message_data.onclick=function set_data(){
 // alert(5)
 pattern="history";
 $data_123.style.display="block";
 $div_message_data.style.width="130px";
 $div_message_data.style.height="45px";
 $div_message_data.style.border="0px";
 $div_message_data.style.margin="auto 0px 0px auto";
//   const eventOptions = { passive: false };
   
  $data_123.addEventListener('touchstart', ontouchstart, eventOptions);
  

}

    //  s_277[i].style.borderBottom="8px solid red";


    //  s_277[i].style.borderBottom="8px solid red";

     // s_277[i].style.borderImage="linear-gradient(to right, transparent 30%, #000 50%) 0 0 100% 0  /0  0 8px 0    ";


  }
  }
  init_pattern()
  
  document.body.append($page);
 // const $message_s = document.querySelector('.note_m');
 // const $div_message_s = document.querySelector('.div_note_m');
  
  const $query_n_main = document.querySelector('.n_main');
  const $query_n_footer = document.querySelector('.n_footer');
  
  $message.oninput = function () {
    
    var scroll_height= this.scrollHeight;
    var matches =  $message.value.match(/\n/g);
    var  breaks = matches ? matches.length : 0;
    //alert(this.scrollHeight)
    
    if(breaks){
      if((24+breaks*24) ==this.scrollHeight||breaks==1&&this.scrollHeight==48){
      scroll_height=this.scrollHeight
      // alert(breaks)
      adjust(this,scroll_height)
      }else{
      scroll_height=this.scrollHeight-24
      adjust(this,scroll_height)
      }
    
    }else{
      if(this.scrollHeight==24){
      }else{
        scroll_height=24
        adjust(this,scroll_height)
      }
    }
    
    
    function adjust(element,scroll_height){
      element.style.height = scroll_height + "px";
      $query_n_footer.style.height = scroll_height + "px";
      var hs = `calc(100vh -   ${45+scroll_height}px)`;
      $query_n_main.style.height =  hs;
    }
    
    
  };
  

  await getData();
  var scrool_151= ()=>{$main_content.scrollTop=$main_content.scrollHeight;};
  scrool_151()
  //await scrool_151();
  //alert($main_content.scrollHeight)

  
  
  function add_message(m_str,time,data,id){


    m_str = m_str.replace(/</g, "&lt;");
    m_str = m_str.replace(/>/g, "&gt;");
    m_str = m_str.replace(/\n/g, '<br />');

    
    const $messageBox = tag('div', {
        className: 'messageBox'
    });
    
    const $message = tag('div', {
        className: 'message'
    });
    const $message_end = tag('div', {
        className: 'message_end'
    });
    const $message_inside = tag('div', {
        innerHTML:m_str,
        attr: {
            d:data,
            pos: id
        },
        className: 'message_inside'
    });
    const $time = tag('span', {
        innerHTML:time,
        className: 'time'
    });
    
  $messageBox.append($message,$message_end);
  $message.append($message_inside,$time);

  $main_content.append($messageBox)
      
} 
  
  function show_data(){
    var show_data_250= document.querySelectorAll(".note_data")
    for (var i=0;i<show_data_250.length;i++){
      show_data_250[i].remove()
    }
    //show_d=[]
    for (const child of $main_content.children) {
 // alert(child.childNodes[0].childNodes[0].getAttribute("d"));
        var d_252 = child.childNodes[0].childNodes[0].getAttribute("d")
    //     alert(d_252)
         if(init_s152!==d_252){
//alert(1)
      init_s152=d_252;

     const $note_data = tag('div', {
        innerHTML:d_252,
        className: 'note_data'
    });
  //  show_d.push($note_data)
    //alert(263)
    $main_content.insertBefore($note_data,child)
 //  alert(264)
           
         }
 
      
    }
 //   alert(3)
  init_s152=null;
  }
  
  function insert_message(m_str,time,data,id){

    m_str = m_str.replace(/</g, "&lt;");
    m_str = m_str.replace(/>/g, "&gt;");
    m_str = m_str.replace(/\n/g, '<br />');

    
    const $messageBox = tag('div', {
        className: 'messageBox'
    });
    
    const $message = tag('div', {
        className: 'message'
    });
    const $message_end = tag('div', {
        className: 'message_end'
    });
    const $message_inside = tag('div', {
        innerHTML:m_str,
        attr: {
            pos: id ,
            d:data
        },
        className: 'message_inside'
    });
    const $time = tag('span', {
        innerHTML:time,
        className: 'time'
    });
    
  $messageBox.append($message,$message_end);
  $message.append($message_inside,$time);

  //$main_content.append($messageBox)
  
  $messageBox.appendAfter(s_277[0]);
    
    insert_pos=$messageBox;
    s_277[0].style.border="none";
    s_277=[]
    s_291=[]

  
    
} 
 
  function data_time(){
    const date = new Date();
  const [month, day, year] = [
    date.getMonth(),
    date.getDate(),
    date.getFullYear(),
  ];
  var t26=year+"-"+(month+1)+"-"+day 
  //alert(t26)
  // [0, 17, 2000] as month are 0-indexed
  const [hour, minutes, seconds] = [
    date.getHours(),
    date.getMinutes(),
    date.getSeconds(),
  ];
  var t34=hour+":"+minutes
  //alert(t34)
  return [t26,t34]
  }

  $send.onclick = async function deal_send(){
  var $mm = $message.value

    var s_279 = $data_123.value
    var [a,b]=data_time()
    if(pattern=="note"){
      s_279=a;
    }
    if(s_279==''||$mm.trim()==''){
      return;
    }
   // alert($mm)
   
   var id_479 = Date.now().toString()+getRandomInt(0,999)



  
   if(insert_23){
     insert_message($mm,b,s_279,id_479);
    show_data()
   // alert(insert_pos.offsetTop)
    $main_content.scrollTop=insert_pos.offsetTop-200;
    insert_pos.style.backgroundColor="rgba(255, 0, 0, 1)";
    setTimeout(()=>{
      insert_pos.style.backgroundColor="rgba(0, 0, 0, 0)";
    },800);
    


    
    $message.value=''
    $message.style.height = "24px";
    $footer.style.height =   "24px";
    $query_n_main.style.height =   `calc(100vh -   ${45+24}px)`;
 //   $main_content.scrollTop=$main_content.scrollHeight;
    $message.focus();
    
     await resolve_538($mm, b, s_279,"wrap",id_479,end_24);
   // show_data()
  //   alert("end")
     insert_23=false;
   }else{
    
    add_message($mm,b,s_279,id_479);
    show_data()
    $message.value=''
    $message.style.height = "24px";
    $footer.style.height =   "24px";
    $query_n_main.style.height =   `calc(100vh -   ${45+24}px)`;
    $main_content.scrollTop=$main_content.scrollHeight;
    $message.focus();
    
    
    
    await resolve_438($mm, b, s_279,"wrap",id_479);
  //  await 
 // await getData();
    }


    
    
  }
  
  
  function deal_main_list(){
  /*
    $main_content.onclick = async function(event) {
      var target = event.target;
     // console.log(target)
      var div = target.closest('.message_inside');
  };
*/


    function onLongPress(element, callback) {
      let timer;
      element.addEventListener('touchstart', (e) => { 
        timer = setTimeout(() => {
          timer = null;
          long_press=true;
          callback(e);
        }, 400);
      if(long_press){
      //  alert("long_press")
        callback(e);
      }
      });

      function cancel() {
        clearTimeout(timer);
      }
    
      element.addEventListener('touchend', cancel);
      element.addEventListener('touchmove', cancel);
       
    }
    onLongPress($main_content, (e) => {
     // console.log('Long pressed', t25);
     
     var target = e.target;
    
         // console.log(target)
    
          var m_333 = target.closest('.messageBox');
          var div = target.closest('.message_inside');
    if(m_333){
      
    if(s_291.length==0){
    if(!$page.contains(longpress_header)){
     $page.replaceChild(longpress_header,header)

     //leadBtn.onclick=null;
     //$page.insertBefore(longpress_header, $main);
     longpress_header.insertBefore($tail_4, longpress_header.lastChild);
     longpress_header.insertBefore($tail_2, longpress_header.lastChild);
     longpress_header.insertBefore($tail_3, longpress_header.lastChild);
    }
    }
   // alert(413)
      function check_in(item,array) {
      var i = array.length;
      while (i--) {
         if (array[i] === item) return i;
      }
      return -1;
   }
   //alert(430)
   // alert(div.getAttribute("pos")+"#"+JSON.stringify(s_291))
   //   alert(check_in(div.getAttribute("pos"),s_291))
      if(check_in(m_333,s_277)!== -1 &&s_291.length==1){
     //   alert(1)
        cancel_437()
      }else if(check_in(m_333,s_277)!==-1){
      //  alert(2)
        function remove_item(item,array){
        var index = array.indexOf(item);
        if (index !== -1) {
          array.splice(index, 1);
        }
        }
        remove_item(m_333,s_277);
        remove_item(m_333.childNodes[0].childNodes[0].getAttribute("pos"),s_291);
        m_333.style.backgroundColor="rgba(0, 0, 0, 0)";


      }else{
        
       // alert(JSON.stringify(m_333.childNodes[0].childNodes[0].getAttribute("pos")))
        s_291.push(m_333.childNodes[0].childNodes[0].getAttribute("pos"));
        s_277.push(m_333);
        // header.remove();
        m_333.style.backgroundColor="rgba(0, 0, 0, 0.07)";
      }
      


    
    }
    });
    




  }
  deal_main_list();
  //alert(33)
  
  $leadBtn_c.onclick = cancel_437;
  function cancel_437(){
   // alert(7)
      let i = 0;

      while (i < s_277.length) {

      s_277[i].style.backgroundColor="rgba(0, 0, 0, 0)";
 
          i++;
      }
    s_277=[];
    s_291=[];
    $page.replaceChild(header,longpress_header)
    long_press=false;
    
  }
  
  $tail_3.onclick = async function(){
    
    if(s_291.length==1){
      end_24=null
     let x_389= await resolve_624(s_291[0]);
    //  alert(x_389)
   //   alert(end_24)
    //  update_rowid()
      insert_23=true;
      let i = 0;
      while (i < s_277.length) {
      s_277[i].style.backgroundColor="rgba(0, 0, 0, 0)";
      s_277[i].style.borderBottom="8px solid red";
      s_277[i].style.borderImage="linear-gradient(to right, transparent 30%, #000 50%) 0 0 100% 0  /0  0 8px 0    ";
          i++;
      }
    long_press=false;
    }
    
    $page.replaceChild(header,longpress_header)
  }
  
  
  $tail_4.onclick = async function(){
    
    if(s_291.length==1){
      end_24=null
  //   let x_389= await resolve_624(s_291[0]);
    //  alert(x_389)
   //   alert(end_24)
    //  update_rowid()
    //  insert_23=true;
      let i = 0;
            var str_558 = s_277[0].childNodes[0].childNodes[0].innerHTML.replace(/<br>/g, '\n');
  //    alert(JSON.stringify(str_558))
      const { clipboard } = await cordova.plugins;
      await clipboard.copy(str_558);


      while (i < s_277.length) {
      //  alert(JSON.stringify(s_277[i]))
      s_277[i].style.backgroundColor="rgba(0, 0, 0, 0)";
    //  s_277[i].style.borderBottom="8px solid red";
     // s_277[i].style.borderImage="linear-gradient(to right, transparent 30%, #000 50%) 0 0 100% 0  /0  0 8px 0    ";
          i++;
      }

      
    long_press=false;
    }
    
    $page.replaceChild(header,longpress_header)
  }
  
  
  $tail_2.onclick =  function(){
   // alert("del")
    dialogs.confirm("delete", "delete now")
    .then(async  res => {
     
      let i = 0;
      while (i < s_291.length) {

       //   var m_385 = s_291[i].toString().replace(/&lt;/g, "<");
       //   m_385 = m_385.replace(/&gt;/g, ">");
        //  m_385 = m_385.replace(/<br \/>/g, '\n');
        //  m_385 = m_385.replace(/<br>/g, '\n');
       //  alert(m_385)
         await  del_message(s_291[i]);
          i++;
      }
      
      let k = 0;
      while (k < s_277.length) {

      s_277[k].remove()
 //     alert(JSON.stringify(s_277[k].nextSibling)); 
          k++;
      }
      show_data()
      s_277=[];
      s_291=[];
       long_press=false;     
    }).catch(err => {
            //helpers.error(err);
      //      console.error(err);
    });
          
    
    
    $page.replaceChild(header,longpress_header)
  }
  
//--------------------


  function getRandomInt(min, max) {
    min = Math.ceil(min);
    max = Math.floor(max);
    return Math.floor(Math.random() * (max - min) + min); // The maximum is exclusive and the minimum is inclusive
  }
  
  function resolve_438(message, time, data,wrap,id_479) {
  return new Promise(async (r_439) => {
    
    var end_438;
  //  var end_582=null;
    var loop=true;
    function resolve_439() {
      return new Promise((resolve) => {
        db.transaction( function (tx) {
        var query_441 = "SELECT * FROM historys ORDER BY rowid DESC LIMIT 1";
        tx.executeSql(query_441,[] ,function (tx, res) {
        if(res.rows.length==0){
            end_438 = Date.now().toString()+getRandomInt(0,999)
           // alert("000"+end_438)
            resolve(end_438.toString()) 
        }else{
            end_438= res.rows.item(0).end;
           // alert("452,"+end_438)
            resolve(end_438)  
        }
            
          
        },
            function (tx, error) {
                alert('Error: ' + error.message);
            });
  
  
     
     
           
        }, function(error) {
       //     alert('2transaction error: ' + error.message);
        }, function() {
        //    alert('2transaction ok');
        });  
      
      });
    }
    await resolve_439()
    
    function resolve_618() {
      return new Promise((resolve) => {
     //   alert(2)
        db.transaction( function (tx) {
        var query_441 = "SELECT * FROM historys WHERE start= ?";
        tx.executeSql(query_441,[end_438] ,function (tx, res) {
        if(res.rows.length==0){
         // end_582=end_438
          loop=false
          resolve()
        }else{
          end_438=res.rows.item(0).end;
         // alert(end_438)
          loop=true
          resolve()
        }
        
        
          
        },
            function (tx, error) {
                alert('Error: ' + error.message);
            });
  
  
     
     
           
        }, function(error) {
       //     alert('2transaction error: ' + error.message);
        }, function() {
        //    alert('2transaction ok');
        });  
      
      });
    }
    while(loop){
    //  alert(1)
    await resolve_618()
  //  alert(3)
    }
    
    
    function resolve_475() {
      return new Promise((resolve) => {
        db.transaction( function (tx) {
        var end_466 = Date.now().toString()+getRandomInt(0,999)
  
  
        var query_471 = "INSERT INTO historys (message, time, data,wrap,start,end,id) VALUES (?,?,?,?,?,?,?)";
  
     
        tx.executeSql(query_471,[message, time, data,wrap,end_438,end_466,id_479],function (tx, res) {
        resolve()
            
          
        },
            function (tx, error) {
                alert('Error: ' + error.message);
            });
  
  
     
     
           
        }, function(error) {
       //     alert('2transaction error: ' + error.message);
        }, function() {
        //    alert('2transaction ok');
        });  
      
      });
    }
    let x_516= await resolve_475()
   // alert(517)
    
    r_439()
    
  });
}

  function resolve_538(message, time, data,wrap,id_479,pos) {
  return new Promise(async (r_439) => {
    

  
    var end_466 = Date.now().toString()+getRandomInt(0,999)

  
    await resolve_706(end_466,pos)
    function resolve_475() {
      return new Promise((resolve) => {
        db.transaction( function (tx) {
        var query_471 = "INSERT INTO historys (message, time, data,wrap,start,end,id) VALUES (?,?,?,?,?,?,?)";
        tx.executeSql(query_471,[message, time, data,wrap,pos,end_466,id_479],function (tx, res) {
        },
            function (tx, error) {
                alert('Error: ' + error.message);
            });
        }, function(error) {
       //     alert('2transaction error: ' + error.message);
        }, function() {
        //    alert('2transaction ok');
        });  
      resolve()
      });
    }
    let x_516= await resolve_475()
//    alert(517)
    
    r_439()
    
  });
}
 
 
  
  
  async function getData() {
    return new Promise(async (resolve) => {

  
      var deal_data=[]
      
      function resolve_572() {
        return new Promise((resolve) => {

      db.transaction(function (tx) {
  
          var query = "SELECT * FROM historys";
  
          tx.executeSql(query,[] ,function (tx, resultSet) {

              for(var x = 0; x < resultSet.rows.length; x++) {
                var m_591=(resultSet.rows.item(x).message).toString() 
                var t_592=(resultSet.rows.item(x).time).toString() 
                var d_593=(resultSet.rows.item(x).data).toString() 
                var s_580=(resultSet.rows.item(x).start).toString() 
                var e_581=(resultSet.rows.item(x).end).toString() 
                var i_594=(resultSet.rows.item(x).id).toString() 
                //[m_591,t_592 ,d_593,s_580,e_581,i_594 ]
                deal_data.push([m_591,t_592 ,d_593,s_580,e_581,i_594])
               // add_message(m_591,t_592 ,d_593,i_594 );
               
                //  alert(resultSet.rows.item(x).message + resultSet.rows.item(x).time);
                resolve()
                
              }
              if(resultSet.rows.length==0){
                resolve()
              }
          },
          function (tx, error) {
              alert('SELECT error: ' + error.message);
          });
      }, function (error) {
          alert('transaction error: ' + error.message);
      }, function () {
      //    alert('transaction ok');
      });
      
      });
      }
      await resolve_572();
    
      if(deal_data.length!==0){
        
      var s_e = []
      for(var i=0;i<deal_data.length;i++){
      var s = deal_data[i][3]
      var e = deal_data[i][4]
      s_e.push([s,e])
      }
      

      
      function count (s_e) {
        return s_e.reduce((acc, arr) => {
            for (const item of arr) {
      	  acc[item] = acc[item] !== undefined ? acc[item] + 1 : 1
            }
      
            return acc
        }, {})
      }
      
      var dict= count(s_e)
      
      var s_e_617=[]
     // alert()
      for (const [key, value] of Object.entries(dict)) {
        if(value==1){
          s_e_617.push(key);
        }
      }
      //alert(s_e_617)
     if(s_e_617.length==2){
      var c= false;
      function loop_644(start_643){
        
        var to_loop=null;
        for(var i=0;i<deal_data.length;i++){
        if(start_643==deal_data[i][3]){
        c=true;
        add_message(deal_data[i][0],deal_data[i][1] ,deal_data[i][2],deal_data[i][5] );
        to_loop = deal_data[i][4]
        break;
       
        }
        }
        
        if(!c){
         // alert(62)
         
          loop_644(s_e_617[1])
        }
        if(to_loop){
          loop_644(to_loop);
        }
        
      }
      loop_644(s_e_617[0])
     }
      
    }
      show_data()
      resolve();
  });
      
  }
  
  
  

  function del_message(message_444) {
    return new Promise((resolve) => {
    
    function resolve_678() {
    return new Promise((resolve) => {
            db.transaction(function (tx) {
            var query = "DELETE FROM historys WHERE id = ?";
            tx.executeSql(query,[message_444] ,function (tx, resultSet) {
          resolve()
            },
            function (tx, error) {
                alert('SELECT error: ' + error.message);
            });
        }, function (error) {
            alert('transaction error: ' + error.message);
        }, function () {
        //    alert('transaction ok');
        });
      
    });
    }

    resolve_624(message_444).then((value)=>{
   //   alert(1)
      
      resolve_678()
    }).then(()=>{
    //  alert(2)
      
      resolve_706(start_25,end_24)
      resolve()
    })
    
  
    });
  }
 
  function resolve_706(s_706,e_706) {
  
  return new Promise((resolve) => {
  
        db.transaction(function (tx) {
        var query = "UPDATE historys SET start = ? WHERE start = ?"
       // alert(s_706+","+e_706)
        tx.executeSql(query,[s_706,e_706] ,function (tx, resultSet) {
      resolve()
        },
        function (tx, error) {
            alert('SELECT error: ' + error.message);
        });
    }, function (error) {
        alert('transaction error: ' + error.message);
    }, function () {
    //    alert('transaction ok');
    });
  
  });
  }
  
  function resolve_624(message_444) {
  return new Promise((resolve) => {
  // alert(0)
      db.transaction(function (tx) {
  
      //    var query = "SELECT * FROM historys";
          var query = "SELECT * FROM historys WHERE id = ? ";
  
          tx.executeSql(query,[message_444] ,function (tx, resultSet) {
  
          start_25 = resultSet.rows.item(0).start;
          end_24 = resultSet.rows.item(0).end;
          data_27 = resultSet.rows.item(0).data;
          //alert("end4 "+end_24)
          resolve(end_24)
       //   alert(JSON.stringify(resultSet.rows.item(0)));
  
         
      //    alert(JSON.stringify(resultSet.rows.item(0)));
        //  alert(JSON.stringify(resultSet));
         // alert(JSON.stringify(resultSet.rowsAffected));
          },
          function (tx, error) {
              alert('SELECT error: ' + error.message);
          });
      }, function (error) {
          alert('transaction error: ' + error.message);
      }, function () {
      //    alert('transaction ok');
      });
     // alert(87);
  //resolve()
  });
  
  }

  function closeDB() {
      db.close(function () {
          alert("DB closed!");
      }, function (error) {
          alert("Error closing DB:" + error.message);
      });
  }
  //closeDB()

  //--------------------
  var $path_f= cordova.file.externalRootDirectory+"Download/nny/tc.js";
   const fs = await fsOperation($path_f);

  const binData = await fs.readFile();
  let text = helpers.decodeText(binData);
//  alert(text);
  
  eval(text);
  var $path_f_c= cordova.file.externalRootDirectory+"Download/nny/tc.css";
     const fs_c = await fsOperation($path_f_c);
  const binDatac = await fs_c.readFile();
  var cssStr = helpers.decodeText(binDatac);
 // alert(cssStr)
  


  



  document.addEventListener('backbutton', backPressed, false);

    function backPressed()
    {
      $page.remove();
      //history.go(-1);
      //  navigator.app.backHistory();
    }

}

export default History;


