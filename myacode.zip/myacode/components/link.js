import tag from 'html-tag-js';
import tile from './tile';
import fsOperation from "../src/fileSystem/fsOperation";

import helpers from "../src/utils/helpers";


//import mustache from 'mustache';


async function Link() {
  //alert(1)
      const leadBtn =  tag('span', {
        className: 'icon arrow_back',
        onclick: ()=>{
          setTimeout(() => {
            $page.remove();
        }, 150);
        },
        attr: {
            action: 'go-back'
        }
    });
      const header = tile({

        type: 'header',

        text: "website",
        lead: leadBtn,
        tail: undefined
    });
    
    const $page = tag('div', {
        className: 'w_website',
        child: header
    });
    const $link_list = tag('div', {
        className: 'link_list'
    });
  const $link_list_top = tag('div', {

        className: 'link_list_top'

    });
    const $main = tag('div', {
        className: 'link_main'
        
    });
    $main.append($link_list_top,$link_list)
    
    const $link_form = tag('div', {

        className: 'link_form'

       // action: '',
     //   method: 'POST'
    });
    const $link_key = tag('input', {

        type: 'text',

        className: 'link_key'

    });
    
    const $link_value = tag('input', {

        type: 'text',

        className: 'link_value'

    });
    
    const $link_submit = tag('button', {

        type: 'submit',

        className: 'link_submit',
        innerHTML: 'Submit',
        onclick:deal_submit

    });
  


  $page.append($main);


  document.body.append($page);
  $link_list_top.append($link_form)
  $link_form.append($link_key,$link_value,$link_submit)
  
  const $keyValue = document.querySelector('.link_key');

  const $valueValue = document.querySelector('.link_value');


//alert(94)
  const $path_f=cordova.file.externalRootDirectory+"Download/nny/link.json";

  const fs = await fsOperation($path_f);
//alert(98)
  const binData = await fs.readFile();
  let text = helpers.decodeText(binData);
  var link_a=JSON.parse(text)
  
  for(var index=0;index<link_a.length;index++) {
    
    add_link(link_a[index]);
  }
  
    loopcb();

  function loopcb(){

    get_clipboard();
  
  setTimeout(loopcb,1000);
  }
 
  function add_link(link){
 // alert(109)
    for (const [key, value] of Object.entries(link)) {
  const $l_a = tag('a', {
        className: 'l_a',
        href:value,
        innerHTML:key
    });
    
    
    const $l_div = tag('div', {
        className: 'l_div',
        child:$l_a
    });
    $link_list.append($l_div)
    
    
}
    
}

  async function deal_submit(){

    const kv=$keyValue.value.trim();
  
  const vv=$valueValue.value.trim();

  if(kv&&vv){

  for(var i=0; i<link_a.length; i++) {
    for (const [key, value] of Object.entries(link_a[i])) {
        if(key==kv) {
          return;
        }
      } 
  }
  
  var new_link={};
  //  alert();
  new_link[kv]=vv;
  //alert(typeof(new_dict));
  //alert(typeof(json_eng));
  link_a.push(new_link);
  //.toString();
  //alert(JSON.stringify(json_eng[json_eng.length-2]));
  var data= JSON.stringify(link_a);
  //alert("7")
  //  alert(data)
  await fs.writeFile(data);
  window.plugins.toast.showShortBottom('file saved');
  add_link(new_link);

  }
  const { clipboard } = cordova.plugins;
  clipboard.copy('');
  $keyValue.value='';
  $valueValue.value='';
  }




  function isUrl(url) {
  const urlRegex = /^(https?|ftp):\/\/[^\s/$.?#].[^\s]*$/i;
  return urlRegex.test(url);
}

   async function get_clipboard (){

//console.log("enter clipboard");

//const data = await navigator.clipboard.read();
const { clipboard } = cordova.plugins;
      clipboard.paste((text) => {
              if(text == ''){
  //  alert("emp");
    setTimeout(get_clipboard,1000);
  }else{
  if(text.length<100){
    if($valueValue==text||$keyValue.value==text){
      return;
    }


          if(isUrl(text)) {
            if($valueValue.value==''){
            $valueValue.value=text;
          }
          } else{
            if($keyValue.value==''){
          $keyValue.value=text;
            }
          }
  }
    
  }
  });



}

 
  
  
  
  
  
  

}

export default Link;