import tag from 'html-tag-js';
import $_bag from '../views/bag.hbs';
import mustache from 'mustache';
import play from "../src/play";
import newfile from "./newfile";


function skillBar() {


  var service = 'Echo';
  var action = 'echo';
//  var args = [    'Test Message'  ];


  var bag=mustache.render($_bag, {})
  const skillLibrary = tag('div', {
  className: 'skill-library',
  id: 'library'
});
skillLibrary.innerHTML=bag


let svg_toggle=`
<svg width="30px" height="30px" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg"><g id="SVGRepo_bgCarrier" stroke-width="0"></g><g id="SVGRepo_tracerCarrier" stroke-linecap="round" stroke-linejoin="round"></g><g id="SVGRepo_iconCarrier"> <path d="M19 9.77794V15M5 15V9.77728M21 11.9998L15.5668 5.96381C14.3311 4.59104 13.7133 3.90466 12.9856 3.65126C12.3466 3.4287 11.651 3.42875 11.0119 3.65141C10.2843 3.90491 9.66661 4.59139 8.43114 5.96433L3 11.9998M3 20.0048C3 20.0048 3.69422 18.8856 4.8 19.0096C6.06078 19.151 7.13275 21 8.4 21C9.66725 21 10.7327 19.0096 12 19.0096C13.2673 19.0096 14.3327 21 15.6 21C16.8672 21 17.9392 19.151 19.2 19.0096C20.3058 18.8856 21 20.0048 21 20.0048M10 11H14V15H10V11Z" stroke="green" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"></path> </g></svg>
`
//
//alert(7)

const skillBar = tag('div', { className: 'skill-bar' });

// 四个槽位
const slot1 = tag('button', {
  className: 'btnz slot selected',
  id: 'slot-1',
  dataset: { name: '1' }
});

const slot2 = tag('button', {
  className: 'btnz slot',
  id: 'slot-2',
  dataset: { name: '2' }
});

const slot3 = tag('button', {
  className: 'btnz slot',
  id: 'slot-3',
  dataset: { name: '3' }
});

const slot4 = tag('button', {
  className: 'btnz slot',
  id: 'slot-4',
  dataset: { name: '4' }
});

// 切换面板按钮
const toggleBtn_ele = tag('button', {
  className: 'btnz panel-toggle',
  id: 'toggleBtnz',
  innerHTML:svg_toggle
});
//alert(42)

// 全部追加到 skillBar
skillBar.append(slot1, slot2, slot3, toggleBtn_ele);
//---------------------------------------------------------------------------------

const $input_go = tag('input', {
  className: 'input-go',
  type: 'text',
  id: 'input-go-id',
  autofocus: true
});

const $button_go = tag('button', {
  id: 'submitBtn-go',
  className: 'btn-go',
  innerHTML: 'OK'
});

const $closeBtn_go = tag('div', {
  id: 'closeBtn-go',
  className: 'close-go',
  innerHTML: '×'
});

const $container_go = tag('div', {
  id: 'sensebox-go',
  className: 'sense-go'
});

$container_go.append($input_go, $button_go);

//---------------------------------------------------------------------------------
// 最后使用示例（和原来一样）
//document.body.append(skillLibrary, skillBar);
// 或其他容器：tag.get('#some-place').append(skillLibrary, skillBar);
root.append(skillLibrary,skillBar,$container_go);

    const $ = s => document.querySelector(s);
    const $$ = s => document.querySelectorAll(s);
    const $$$ = s => document.getElementById(s);
    
        const library = document.getElementById('library');
        const toggleBtn = document.getElementById('toggleBtnz');
        const slots = document.querySelectorAll('.slot');


        // 函数：获取当前选中的槽位，确保总是最新的
        function getCurrentSlot() {
            return document.querySelector('.slot.selected') || slots[0];
        }

        // 1. 打开/关闭面板
        toggleBtn.addEventListener('click', () => {
            library.classList.toggle('active');
        });
//alert(38)
        const getEditor = () => {
            if (window.editorManager && editorManager.editor) {
                return editorManager.editor;
            }
            console.error("编辑器尚未初始化");
            return null;
        };
        
                // 2. 选择要替换的槽位
        slots.forEach(slot => {
            slot.addEventListener('click', () => {
                slots.forEach(s => s.classList.remove('selected'));
                slot.classList.add('selected');
                const currentSlot = getCurrentSlot(); // 使用函数获取，确保最新
                const name = currentSlot.dataset.name || currentSlot.id || 'unknown'; // 如果没有 data-name 就用 id
                const editor = getEditor(); // 统一获取

                if (!editor) return; // 如果编辑器没加载，直接拦截，防止后面报错
                if (!library.classList.contains('active')) {
                    if(name=='play'){
                     play_fun()
                      //destroyAndCleanup()
                    }
                    else if(name=="unlock") {
                        unlock_onclick()
                    }
                    else if(name=="lock") {
                        lock_onclick()
                    }
                    else if(name=="new") {
                        newfile()
                    }
                    else if(name=="play_math") {
                        play("newui")
                    }
                    else if(name=="end") {
                        //let  editor = editorManager.editor;
                        var row = editor.session.getLength() - 1
                    
                        while (true) {
                    
                          var wholelinetxt = editor.session.getLine(row);
                          if (wholelinetxt.trim() !== '') {
                            break;
                          }
                          if (row == 0) {
                            break;
                          }
                          row--;
                        }
                    
                        var column = editor.session.getLine(row).length // or simply Infinity
                    
                        editor.gotoLine(row+1 , column)
                        editor.renderer.scrollCursorIntoView(); 
                        //editor.centerSelection();
       
                        
                    }
                    else if(name=="copy"){
                       // let  editor = editorManager.editor;
                        editor.execCommand("copy");
                        //alert(170)
                    }
                    else if(name=="split"){ 
                       // let  editor = editorManager.editor;
                        // 获取当前光标位置 {row: x, column: y}
                        var pos = editor.getCursorPosition();
                        // 在该位置插入文本
                        editor.session.insert(pos, "---------------------------------------------------------------------------------");
                        editor.blur();
                          //this code important, waste my 1 day
                        editor.focus();
                      
                    }
                    else if(name=="line"){
                       // let  editor = editorManager.editor;
                        editor.selection.selectLine();
                        editor.blur();
                          //this code important, waste my 1 day
                        editor.focus();
                       }
                    else if(name=="go"){
                        //alert(184)
                        //let  editor = editorManager.editor;
                        $$$('sensebox-go').classList.toggle('active-go');
                    }
                    else if(name=="one"){
                     // 1. 获取当前光标所在的行号
                        var currentRow = editor.getCursorPosition().row;
                        
                        // 2. 在该行的第 0 列（即开头）插入内容
                        editor.session.insert({row: currentRow, column: 0}, ">>");
                        editor.blur();
                          //this code important, waste my 1 day
                        editor.focus();
                    }
                    else if(name=="fold"){
                       // let  editor = editorManager.editor;
                        editor.execCommand("foldall");
                        //alert(170)
                    }
                    
                    else if(name=="square_brackets"){
                      editor.session.insert(editor.getCursorPosition(), "[ ]")
                      editor.blur();
                        //this code important, waste my 1 day
                      editor.focus();
                    }
                    else if(name=="curly_brackets"){
                      editor.session.insert(editor.getCursorPosition(), "{ }")
                      editor.blur();
                        //this code important, waste my 1 day
                      editor.focus();
                      
                    }
                    else if(name=="angle_brackets"){
                      editor.session.insert(editor.getCursorPosition(), "<>")
                      editor.blur();
                        //this code important, waste my 1 day
                      editor.focus();
                    }
             
             else{
                    alert(`当前工具：${name}`);
                    }
                }
                console.log(`Activated tool: ${name}`);
            });
        });
//alert(58)
        // 3. 点击仓库技能进行替换
        library.addEventListener('click', (e) => {
            const btnz = e.target.closest('.lib-item');
            if (btnz) {
                const currentSlot = getCurrentSlot(); // 使用函数获取，确保总是最新的选中槽位
                if (currentSlot) {
                    // 复制 SVG 内容
                    currentSlot.innerHTML = btnz.innerHTML;
                    currentSlot.dataset.name = btnz.dataset.name || btnz.dataset.id || 'unknown-icon';

                    // 替换后的视觉反馈
                    currentSlot.style.transform = 'scale(1.1)';
                    setTimeout(() => currentSlot.style.transform = 'scale(1)', 200);
                }
            }
        
            
        });
     $$$('submitBtn-go').onclick =async  function() {
    //    $$$('sensebox-go').classList.remove('active-go');
        let to=$$$('input-go-id').value
        let  editor = editorManager.editor;
        let toN= parseInt(to, 10)
        editor.gotoLine(toN, 0);
       //editor.focus(); // 必须获取焦点
       // editor.centerSelection();
        editor.renderer.scrollCursorIntoView(); 
        //draggable.moveSpeed = parseFloat(speed); 
     }
     /*
     $$$('closeBtn-go').onclick =async  function() {
        $$$('sensebox-go').classList.remove('active-go');
     
     }       
*/



        // 初始填充第一个槽位，并设置 data-name

            slots[0].innerHTML = $$$('play_skill').innerHTML;
            slots[0].dataset.name = $$$('play_skill').dataset.name || firstLibItem.dataset.id || 'unknown-icon';
           slots[1].innerHTML = $$$('play_math_skill').innerHTML;
          slots[1].dataset.name = $$$('play_math_skill').dataset.name || firstLibItem.dataset.id || 'unknown-icon';
            slots[2].innerHTML = $$$('new_skill').innerHTML;
            slots[2].dataset.name = $$$('new_skill').dataset.name || firstLibItem.dataset.id || 'unknown-icon';
    
    

  function successHandler(message) {
    //alert('success:'+ message);
  }

  function errorHandler(err) {
    alert('failed' + err);
  }

    
  function lock_onclick() {
//alert(1)
    var str_name = editorManager.activeFile.filename;
    editorManager.removeFile(editorManager.activeFile);
    var cmd1 = [];
    cmd1.push(str_name);
    cmd1.push("lock");
   // alert(2)
    cordova.exec(successHandler, errorHandler, service, action, cmd1);

  }

  function unlock_onclick() {

    var cmd2 = [];
    cmd2.push(editorManager.activeFile.filename);
    cmd2.push("unlock");
    cordova.exec(successHandler, errorHandler, service, action, cmd2);

  }

function play_fun() {

    play()

  }


            
return skillBar;
}


 
export default skillBar;

