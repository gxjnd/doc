import tag from 'html-tag-js';

import FileBrowser from '../fileBrowser/fileBrowser';

import fsOperation from "../src/fileSystem/fsOperation";

import openFile from '../src/openFile';



 function newfile() {
// 创建 modal-overlay
//alert(5)
// 创建标签组：文件路径
  const setting = appSettings.defaultSettings
   
const labelFilePath = tag('label', { for: 'filePath', innerHTML: 'file path' });
//alert(8)
const inputFilePath = tag('input', { 
  type: 'text', 
  id: 'filePath', 
  placeholder: 'please input path' 
});
//alert(14)
const buttonBrowse = tag('button', { 
  className: 'path-btn', 
  id: 'browseBtn', 
  innerHTML: '...' 
});
//alert(20)
const divFilePath = tag('div', { 
  style: {display: 'flex'}, 
  children: [inputFilePath, buttonBrowse] 
});
//alert(25)
const filePathGroup = tag('div', { 
  className: 'form-group', 
  children: [labelFilePath, divFilePath] 
});
//alert(30)
// 创建标签组：文件后缀
const labelFileExtension = tag('label', { 
  for: 'fileExtension', 
  innerHTML: 'extension' 
});
//alert(36)

var list_extension = setting.extension
/*
var list_extension= ['txt','js','kt','html','css','json','py','c']
const selectFileExtension = tag('select', { 
  id: 'fileExtension', 
  children: [
    tag('option', { value: '.txt', innerHTML: '.txt' }),
    tag('option', { value: '.doc', innerHTML: '.doc' }),
    tag('option', { value: '.pdf', innerHTML: '.pdf' }),
    tag('option', { value: '.jpg', innerHTML: '.jpg' }),
    tag('option', { value: '.png', innerHTML: '.png' })
  ]
});
*/
const selectFileExtension = tag('select', { 
  id: 'fileExtension', 
  children: list_extension.map(ext => 
    tag('option', { value: `.${ext}`, innerHTML: `.${ext}` })
  )
});
//alert(47)


const fileExtensionGroup = tag('div', { 
  className: 'form-group', 
  children: [labelFileExtension, selectFileExtension] 
});

// 创建按钮组
const buttonCancel = tag('button', { 
  className: 'cancel-btn', 
  id: 'cancelBtn', 
  innerHTML: 'cancel' 
});

const buttonConfirm = tag('button', { 
  id: 'confirmBtn', 
  innerHTML: 'ok' 
});
//alert(64)
const modalButtons = tag('div', { 
  className: 'modal-buttons', 
  children: [buttonCancel, buttonConfirm] 
});

// 创建模态框
const modal = tag('div', { className: 'modal', children: [
  filePathGroup,
  fileExtensionGroup,
  modalButtons
]});
//alert(76)
// 创建模态覆盖层
const modalOverlay = tag('div', { 
  className: 'modal-overlay',
  id: 'modalOverlay',
  children: [modal]
});
//alert(83)


// 将模态覆盖层添加到文档中
document.body.append(modalOverlay);
  
inputFilePath.value = setting.filepath
selectFileExtension.value = setting.useext
 
inputFilePath.scrollLeft = inputFilePath.scrollWidth;
      
    buttonCancel.addEventListener('click', () => {
      //alert(40)
      modalOverlay.style.display = 'none';
    });
//alert(42)
    // 确认按钮事件
    buttonConfirm.addEventListener('click', () => {
      const filePath = inputFilePath.value;
      const fileExtension = selectFileExtension.value;
      if (filePath) {
      //  alert(`path: ${filePath}\t extension: ${fileExtension}`);
                            setting['filepath'] = filePath;
                            setting['useext'] = fileExtension;
                  //setting.filepath
                 // alert(JSON.stringify(setting))
 
                 // fs.writeFile(search_json, JSON.stringify(values, undefined, 4), true, false)
                  appSettings.update(setting)
       
       
let newFileName; // 在外部定义变量

fsOperation(filePath)
  .then(fs => {
    newFileName = updateTimestamp() + fileExtension; // 在 then 内部赋值

    return fs.createFile(newFileName);
  })
  .then(() => {
    var file_url = filePath+newFileName
    const options = {
      name:newFileName, // 可以在后续的 then 中访问
      uri:file_url
    };
//alert(JSON.stringify(options))
    openFile(options);
  })
  .then(() => {
    modalOverlay.style.display = 'none';
  })
  .catch(error => {
    console.error('Error occurred:', error);
  });
        //alert(136)
      } else {
        alert('请输入文件路径！');
      }
    });

    // 模拟浏览按钮（这里仅为示例，可以集成实际文件选择功能）
    buttonBrowse.addEventListener('click', () => {
FileBrowser('folder')
      .then(res => {
        inputFilePath.value = res.url
  inputFilePath.scrollLeft = inputFilePath.scrollWidth;
      
        //  alert(res.url)
      //     alert( res.name)
          });
        

         
      
      
    });
  
  
  
 // alert(87)
}
        function updateTimestamp() {
            const now = new Date();
            const day = now.getDate(); // 获取当前日期的日
            const timestamp = Math.floor(now.getTime() / 1000); // 获取当前时间戳（秒）
            const randomNumber = Math.floor(Math.random() * 10); // 生成一个0-9的随机数字

            // 格式化时间戳
           // const formattedTimestamp = `时间戳: ${timestamp}`;
          //  document.getElementById('currentTimestamp').textContent = `几号: ${day} - ${formattedTimestamp}`;

            // 生成简洁文件名
            const filename = `${day}-${timestamp}-${randomNumber}`;
           
           return filename;// document.getElementById('filename').textContent = `文件名: ${filename}`;
        }
        
export default newfile;








