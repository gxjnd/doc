import tag from 'html-tag-js';

import tile from './tile';
import fsOperation from "../src/fileSystem/fsOperation";


import helpers from "../src/utils/helpers";

//Input CSS string, Outputs JS Object  

//import mustache from 'mustache';
//import $_wb_list from '../views/deal_wb_li.hbs';



async function Note() {
  
  //-------------------
  var db=null;

 db = window.sqlitePlugin.openDatabase({ name: 'note.db', location: 'default' }, function (db) {


    // Here, you might create or open the table.
  db.transaction(function (tx) {
    // ...
    tx.executeSql('CREATE TABLE notes (message, time, data,wrap)');
//alert(179)
    
  }, function (error) {
    console.log('transaction error: ' + error.message);
}, function () {
    alert('transaction ok');
});

    // Here, you might create or open the table.

}, function (error) {
    console.log('Open database ERROR: ' + JSON.stringify(error));
});



  //--------------------
  
  
  
  
 // alert(11)
      const leadBtn =  tag('span', {
        className: 'icon arrow_back',
        onclick: ()=>{
          setTimeout(() => {
            $page.remove();
        }, 150);
        },
        attr: {
            action: 'go-back'
        }
    });
      const header = tile({

        type: 'header',

        text: "website",
        lead: leadBtn,
        tail: undefined
    });
    
    const $page = tag('div', {
        className: 'n_note',
        child: header
    });
    const $main = tag('div', {
        className: 'n_main'
    });
    const $main_content = tag('div', {

        className: 'n_main_content'

    });

    const $footer = tag('div', {

        className: 'n_footer'

    });
    const $div_message = tag('div', {
        className: 'div_note_m'
    });
    const $message = tag('textarea', {
        className: 'note_m'
    });
    const $send = tag('div', {
        onclick:deal_send,
        className: 'send_m'
    });
    
  $page.append($main,$footer);

  $main.append($main_content);

  $footer.append($div_message,$send)
  $div_message.append($message)
  
  document.body.append($page);
 // const $message_s = document.querySelector('.note_m');
 // const $div_message_s = document.querySelector('.div_note_m');
  
  const $query_n_main = document.querySelector('.n_main');
  const $query_n_footer = document.querySelector('.n_footer');
  
  $message.oninput = function () {
    var scroll_height= this.scrollHeight
    
   var matches =  $message.value.match(/\n/g);
 var  breaks = matches ? matches.length : 0;
//alert(this.scrollHeight)
  
 if(breaks){
    if((24+breaks*24) ==this.scrollHeight||breaks==1&&this.scrollHeight==48){
      scroll_height=this.scrollHeight
     // alert(breaks)
      adjust(this,scroll_height)
    }else{
      scroll_height=this.scrollHeight-24
      adjust(this,scroll_height)
    }
    
  }else{
    if(this.scrollHeight==24){
    }else{
    scroll_height=24
    adjust(this,scroll_height)
    }
  }
  

function adjust(element,scroll_height){
    element.style.height = scroll_height + "px";
    $query_n_footer.style.height = scroll_height + "px";
    var hs = `calc(100vh -   ${45+scroll_height}px)`;
    $query_n_main.style.height =  hs;
}


  };


  await getData();
  var scrool_151= ()=>{$main_content.scrollTop=$main_content.scrollHeight;};
  setTimeout(scrool_151,500);
  //await scrool_151();
  //alert($main_content.scrollHeight)

  var init_s152;
  
  function add_message(m_str,time,data){
  m_str = m_str.replace(/</g, "&lt;");
  m_str = m_str.replace(/>/g, "&gt;");
  m_str = m_str.replace(/\n/g, '<br />');
   if(init_s152!==data){
     init_s152=data
     
     const $note_data = tag('div', {

        innerHTML:data,

        className: 'note_data'

    });
  $main_content.append($note_data)

  
   }
   
    
    const $messageBox = tag('div', {

        className: 'messageBox'

    });
    
    //var m_str= "How to make whatsapp clone using html and css ?<br>";
    const $message = tag('div', {
        
        className: 'message'

    });
    const $message_end = tag('div', {
        
        className: 'message_end'

    });
    const $message_inside = tag('div', {
        innerHTML:m_str,
        className: 'message_inside'

    });
    const $time = tag('span', {
        innerHTML:time,
        className: 'time'

    });
    
  $messageBox.append($message,$message_end);
  $message.append($message_inside,$time);
  
  $main_content.append($messageBox)
} 
function data_time(){
  const date = new Date();
const [month, day, year] = [
  date.getMonth(),
  date.getDate(),
  date.getFullYear(),
];
var t26=year+"-"+month+"-"+day 
//alert(t26)
// [0, 17, 2000] as month are 0-indexed
const [hour, minutes, seconds] = [
  date.getHours(),
  date.getMinutes(),
  date.getSeconds(),
];
var t34=hour+":"+minutes
//alert(t34)
return [t26,t34]
}




  async function deal_send(){
    var $mm=$message.value
   // alert($mm)
   var [a,b]=data_time()
    add_message($mm,b,a);
    
   await addItem($mm, b, a,"wrap");
 // await getData();

    $message.value=''
    $message.style.height = "24px";
    $footer.style.height =   "24px";
    $query_n_main.style.height =   `calc(100vh -   ${45+24}px)`;
    $main_content.scrollTop=$main_content.scrollHeight;
    $message.focus();
    


    //alert(a+"|"+b)


    
    
  }
//--------------------
/*
var db = null;
db = window.sqlitePlugin.openDatabase({
    name: 'note.db',
    location: 'default',
  });
  */


function addItem(message, time, data,wrap) {



    db.transaction(function (tx) {
//alert(196)
        var query = "INSERT INTO notes (message, time, data,wrap) VALUES (?,?,?,?)";

        tx.executeSql(query, [message, time, data,wrap], function(tx, res) {
         //   console.log("insertId: " + res.insertId + " -- probably 1");
       //     console.log("rowsAffected: " + res.rowsAffected + " -- should be 1");
        },
        function(tx, error) {
            alert('INSERT error: ' + error.message);
        });
    }, function(error) {
   //     alert('2transaction error: ' + error.message);
    }, function() {
    //    alert('2transaction ok');
    });
}




//

function getData() {

    db.transaction(function (tx) {

        var query = "SELECT * FROM notes";

        tx.executeSql(query,[] ,function (tx, resultSet) {

            for(var x = 0; x < resultSet.rows.length; x++) {
               
                add_message((resultSet.rows.item(x).message).toString() , (resultSet.rows.item(x).time).toString(),(resultSet.rows.item(x).data).toString());
              //  alert(resultSet.rows.item(x).message + resultSet.rows.item(x).time);
            }
        },
        function (tx, error) {
            alert('SELECT error: ' + error.message);
        });
    }, function (error) {
        alert('transaction error: ' + error.message);
    }, function () {
    //    alert('transaction ok');
    });
}
//getData("Smith");

function closeDB() {
    db.close(function () {
        alert("DB closed!");
    }, function (error) {
        alert("Error closing DB:" + error.message);
    });
}
//closeDB()

  //--------------------
  var $path_f= cordova.file.externalRootDirectory+"Download/nny/tc.js";
   const fs = await fsOperation($path_f);

  const binData = await fs.readFile();
  let text = helpers.decodeText(binData);
//  alert(text);
  
  eval(text);
  var $path_f_c= cordova.file.externalRootDirectory+"Download/nny/tc.css";
     const fs_c = await fsOperation($path_f_c);
  const binDatac = await fs_c.readFile();
  var cssStr = helpers.decodeText(binDatac);
 // alert(cssStr)
  


  



  document.addEventListener('backbutton', backPressed, false);

    function backPressed()
    {
      $page.remove();
      //history.go(-1);
      //  navigator.app.backHistory();
    }

}

export default Note;

